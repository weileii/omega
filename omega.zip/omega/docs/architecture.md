# Architecture

```
src/omega/
  core/     registry, tool base class, parameter validation, safe runner (no UI, no I/O)
  config/   settings (JSON, atomic save), logging setup
  ui/       renderer: colour themes, panels, tables, menus, prompts, sanitising
  menu/     the interactive application (screens and navigation)
  cli/      argparse entry point for scripting
  tools/    one package per category; modules auto-discovered at startup
```

Dependency direction: `tools -> core`, `menu/cli -> core, config, ui`. `core` imports nothing from
the other layers. A tool returns a `ToolResult`; it never prints. The same `Param` declarations drive
the interactive prompts and the CLI `--arg` options, so a tool is written once.

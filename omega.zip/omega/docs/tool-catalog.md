# Tool catalog

Generated from the registry: **16 of 120** planned tools are implemented. Only implemented tools are listed.

## 01 Network & Security (0/15)

_Nothing implemented yet._

## 02 OSINT & Public Information (0/15)

_Nothing implemented yet._

## 03 Web & Domain Tools (0/12)

_Nothing implemented yet._

## 04 File & Metadata Tools (0/12)

_Nothing implemented yet._

## 05 System & Diagnostics (0/12)

_Nothing implemented yet._

## 06 Developer Tools (12/12)

| # | ID | Name | Description | Permissions |
|---|----|------|-------------|-------------|
| 067 | `dev.json_validator` | JSON Validator | Check JSON is well-formed and summarise its structure. | none |
| 068 | `dev.json_formatter` | JSON Formatter | Pretty-print or minify JSON. | none |
| 069 | `dev.yaml_validator` | YAML Validator | Check YAML syntax (safe loader only; needs PyYAML). | none |
| 070 | `dev.toml_validator` | TOML Validator | Check TOML syntax and list its top-level keys. | none |
| 071 | `dev.xml_validator` | XML Validator | Check XML is well-formed. DTDs and entities are refused for safety. | none |
| 072 | `dev.base64` | Base64 Encoder/Decoder | Encode text to Base64 or decode Base64 (standard or URL-safe). | none |
| 073 | `dev.url_codec` | URL Encoder/Decoder | Percent-encode or decode text (component or form style). | none |
| 074 | `dev.text_diff` | Text Diff Tool | Unified diff of two texts or files. | none |
| 075 | `dev.code_statistics` | Code Statistics | Count files and code/comment/blank lines per language. | filesystem:read |
| 076 | `dev.python_syntax` | Python Syntax Checker | Parse Python source (file, directory or pasted code). Never executes it. | filesystem:read |
| 077 | `dev.python_project` | Python Project Inspector | Summarise a Python project's layout, metadata and tooling. | filesystem:read |
| 078 | `dev.dependency_inspector` | Dependency Inspector | List declared dependencies and whether each is installed here. | filesystem:read |

## 07 Data & Conversion (1/12)

| # | ID | Name | Description | Permissions |
|---|----|------|-------------|-------------|
| 085 | `data.number_base` | Number Base Converter | Convert integers between bases 2-36 (0x/0o/0b prefixes accepted). | none |

## 08 Privacy & Data Protection (3/10)

| # | ID | Name | Description | Permissions |
|---|----|------|-------------|-------------|
| 091 | `privacy.password_strength` | Password Strength Estimator | Heuristic strength estimate. The password stays on this machine. | none |
| 092 | `privacy.password_generator` | Secure Password Generator | Generate passwords with the OS secure random source. | none |
| 093 | `privacy.token_generator` | Random Token Generator | Generate hex, URL-safe or UUID tokens. | none |

## 09 Automation & Utilities (0/10)

_Nothing implemented yet._

## 10 OMEGA Core & Plugins (0/10)

_Nothing implemented yet._

"""User settings: JSON on disk, validated on load, safe defaults on any problem."""

from __future__ import annotations

import json
import logging
import logging.handlers
import os
import sys
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

THEME_NAMES = ("omega", "contrast", "mono")
LOG_LEVELS = ("DEBUG", "INFO", "WARNING", "ERROR")
UNICODE_MODES = ("auto", "on", "off")
_LOGGER_TAG = "_omega_file_handler"


def omega_home() -> Path:
    """Per-user config directory (override with OMEGA_HOME)."""
    env = os.environ.get("OMEGA_HOME")
    if env:
        return Path(env).expanduser()
    if os.name == "nt":
        base = os.environ.get("APPDATA")
        return (Path(base) if base else Path.home() / "AppData" / "Roaming") / "omega"
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "omega"
    xdg = os.environ.get("XDG_CONFIG_HOME")
    return (Path(xdg) if xdg else Path.home() / ".config") / "omega"


def config_path() -> Path:
    return omega_home() / "config.json"


def log_path() -> Path:
    return omega_home() / "logs" / "omega.log"


def _as_bool(raw: str) -> bool:
    low = raw.strip().lower()
    if low in {"1", "y", "yes", "true", "on"}:
        return True
    if low in {"0", "n", "no", "false", "off"}:
        return False
    raise ValueError("expected yes or no")


@dataclass
class Settings:
    theme: str = "omega"
    color: bool = True
    clear_screen: bool = True
    unicode: str = "auto"
    log_level: str = "INFO"
    max_output_lines: int = 200
    disabled_tools: list[str] = field(default_factory=list)
    tool_settings: dict[str, dict[str, Any]] = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list, init=False, repr=False, compare=False)

    SCALARS = ("theme", "color", "clear_screen", "unicode", "log_level", "max_output_lines")

    def to_dict(self) -> dict[str, Any]:
        return {
            "theme": self.theme,
            "color": self.color,
            "clear_screen": self.clear_screen,
            "unicode": self.unicode,
            "log_level": self.log_level,
            "max_output_lines": self.max_output_lines,
            "disabled_tools": sorted(set(self.disabled_tools)),
            "tool_settings": self.tool_settings,
        }

    def set_value(self, key: str, raw: str) -> None:
        """Validate and set one scalar setting. Raises ValueError with a clear message."""
        if key not in self.SCALARS:
            raise ValueError(f"unknown setting '{key}'. Valid: {', '.join(self.SCALARS)}")
        if key == "theme":
            self.theme = _choice(raw, THEME_NAMES, key)
        elif key == "unicode":
            self.unicode = _choice(raw, UNICODE_MODES, key)
        elif key == "log_level":
            self.log_level = _choice(raw.upper(), LOG_LEVELS, key)
        elif key in ("color", "clear_screen"):
            setattr(self, key, _as_bool(raw))
        else:
            try:
                number = int(raw)
            except ValueError:
                raise ValueError("max_output_lines must be a whole number") from None
            if not 20 <= number <= 5000:
                raise ValueError("max_output_lines must be between 20 and 5000")
            self.max_output_lines = number

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Settings:
        s = cls()
        for key in cls.SCALARS:
            if key not in data:
                continue
            value = data[key]
            try:
                if isinstance(value, bool):
                    value = "yes" if value else "no"
                s.set_value(key, str(value))
            except ValueError as exc:
                s.warnings.append(f"ignored invalid '{key}': {exc}")
        disabled = data.get("disabled_tools", [])
        if isinstance(disabled, list) and all(isinstance(x, str) for x in disabled):
            s.disabled_tools = list(disabled)
        elif "disabled_tools" in data:
            s.warnings.append("ignored invalid 'disabled_tools'")
        tool_settings = data.get("tool_settings", {})
        if isinstance(tool_settings, dict):
            s.tool_settings = {
                k: v for k, v in tool_settings.items() if isinstance(k, str) and isinstance(v, dict)
            }
        return s

    @classmethod
    def load(cls, path: Path | None = None) -> Settings:
        path = path or config_path()
        if not path.exists():
            return cls()
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                raise ValueError("top level must be an object")
        except (OSError, ValueError) as exc:
            s = cls()
            s.warnings.append(f"could not read {path} ({exc}); using defaults")
            return s
        return cls.from_dict(data)

    def save(self, path: Path | None = None) -> None:
        """Atomically write settings (temp file + rename)."""
        path = path or config_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=".config-", suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                json.dump(self.to_dict(), fh, indent=2)
                fh.write("\n")
            os.replace(tmp, path)
        except OSError:
            Path(tmp).unlink(missing_ok=True)
            raise

    def is_disabled(self, tool_id: str) -> bool:
        return tool_id in self.disabled_tools


def _choice(raw: str, options: tuple[str, ...], key: str) -> str:
    low = raw.strip().lower()
    for option in options:
        if option.lower() == low:
            return option
    raise ValueError(f"{key} must be one of: {', '.join(options)}")


def setup_logging(settings: Settings, path: Path | None = None) -> None:
    """Log to a rotating file; silently skip if the directory is not writable."""
    root = logging.getLogger("omega")
    root.setLevel(getattr(logging, settings.log_level, logging.INFO))
    root.propagate = False
    for handler in root.handlers:
        if getattr(handler, _LOGGER_TAG, False):
            root.removeHandler(handler)
            handler.close()
    target = path or log_path()
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        handler: logging.Handler = logging.handlers.RotatingFileHandler(
            target, maxBytes=512_000, backupCount=3, encoding="utf-8"
        )
    except OSError:
        handler = logging.NullHandler()
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))
    setattr(handler, _LOGGER_TAG, True)
    root.addHandler(handler)

"""OMEGA subpackage."""

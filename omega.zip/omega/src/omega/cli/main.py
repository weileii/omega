"""Command-line entry point. No arguments opens the interactive menu."""

from __future__ import annotations

import argparse
import getpass
import json
import sys
from collections.abc import Sequence

from omega import __version__
from omega.config.settings import Settings, config_path, setup_logging
from omega.core.categories import CATEGORY_BY_KEY, TOTAL_TARGET
from omega.core.errors import RegistryError
from omega.core.registry import Registry, default_registry
from omega.core.runner import run_tool
from omega.menu.app import MenuApp
from omega.tools import load_builtin_tools
from omega.ui.console import UI, sanitize


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="omega",
        description="OMEGA - modular terminal toolkit. Run with no command for the interactive menu.")
    p.add_argument("--version", action="store_true", help="print version and exit")
    sub = p.add_subparsers(dest="command")
    sub.add_parser("menu", help="open the interactive menu (default)")
    lst = sub.add_parser("list", help="list implemented tools")
    lst.add_argument("--category", help="category key, e.g. dev")
    lst.add_argument("--json", action="store_true", help="machine-readable output")
    info = sub.add_parser("info", help="show a tool's metadata and parameters")
    info.add_argument("tool", help="tool id, short name or catalog number")
    run = sub.add_parser("run", help="run a tool non-interactively")
    run.add_argument("tool", help="tool id, short name or catalog number")
    run.add_argument("--arg", "-a", action="append", default=[], metavar="NAME=VALUE",
                     help="tool argument (repeatable). For secret arguments use NAME=- to read "
                          "from a hidden prompt or stdin")
    run.add_argument("--json", action="store_true", help="machine-readable output")
    cfg = sub.add_parser("config", help="view or change settings")
    cfg.add_argument("action", choices=("show", "path", "set", "reset", "enable", "disable"))
    cfg.add_argument("key", nargs="?", help="setting name (set) or tool id (enable/disable)")
    cfg.add_argument("value", nargs="?", help="new value (set)")
    return p


def _parse_args(pairs: Sequence[str]) -> dict[str, str]:
    out: dict[str, str] = {}
    for pair in pairs:
        if "=" not in pair:
            raise ValueError(f"argument '{pair}' must look like NAME=VALUE")
        name, value = pair.split("=", 1)
        out[name.strip()] = value
    return out


def _cmd_list(args: argparse.Namespace, registry: Registry, ui: UI) -> int:
    tools = registry.all()
    if args.category:
        if args.category not in CATEGORY_BY_KEY:
            ui.error(f"unknown category '{sanitize(args.category)}'. "
                     f"Valid: {', '.join(CATEGORY_BY_KEY)}")
            return 2
        tools = [t for t in tools if t.category == args.category]
    if args.json:
        print(json.dumps([{"id": t.id, "number": t.number, "name": t.name, "category": t.category,
                           "description": t.description, "version": t.version} for t in tools],
                         indent=2))
        return 0
    ui.table(["#", "ID", "Name", "Description"],
             [[f"{t.number:03d}", t.id, t.name, t.description] for t in tools])
    ui.print(ui.style("muted", f"\n  {len(registry)} of {TOTAL_TARGET} planned tools implemented"))
    return 0


def _cmd_info(args: argparse.Namespace, registry: Registry, ui: UI) -> int:
    tool = registry.get(args.tool)
    ok, reason = tool.available()
    ui.kv([("ID", tool.id), ("Number", f"{tool.number:03d}"), ("Name", tool.name),
           ("Description", tool.description), ("Category", CATEGORY_BY_KEY[tool.category].name),
           ("Version", tool.version), ("Status", tool.status if ok else f"unavailable ({reason})"),
           ("Permissions", ", ".join(tool.permissions) or "none")])
    if tool.params:
        ui.print()
        ui.table(["Argument", "Type", "Default", "Prompt"],
                 [[p.name, p.kind, "-" if p.default is None else str(p.default), p.prompt]
                  for p in tool.params])
    return 0


def _read_secret(name: str) -> str:
    if sys.stdin.isatty():
        return getpass.getpass(f"{name}: ")
    return sys.stdin.readline().rstrip("\r\n")


def _cmd_run(args: argparse.Namespace, registry: Registry, settings: Settings, ui: UI) -> int:
    tool = registry.get(args.tool)
    raw = _parse_args(args.arg)
    secrets = {p.name for p in tool.params if p.kind == "secret"}
    for name in secrets & {k for k, v in raw.items() if v == "-"}:
        raw[name] = _read_secret(name)
    result = run_tool(tool, raw, settings.disabled_tools)
    if args.json:
        print(json.dumps(result.to_dict(), indent=2, ensure_ascii=False))
        return 0 if result.ok else 1
    mark = ui.style("ok", ui.sym("ok")) if result.ok else ui.style("error", ui.sym("err"))
    ui.print(f"{mark} {sanitize(result.title)}" + (f" - {sanitize(result.summary)}" if result.summary else ""))
    ui.kv(result.rows)
    if result.text:
        ui.print()
        ui.print(sanitize(result.text))
    return 0 if result.ok else 1


def _cmd_config(args: argparse.Namespace, settings: Settings, registry: Registry, ui: UI) -> int:
    path = config_path()
    if args.action == "path":
        print(path)
        return 0
    if args.action == "show":
        print(json.dumps(settings.to_dict(), indent=2))
        return 0
    try:
        if args.action == "reset":
            settings = Settings()
        elif args.action == "set":
            if not args.key or args.value is None:
                raise ValueError("usage: omega config set NAME VALUE")
            settings.set_value(args.key, args.value)
        else:
            if not args.key:
                raise ValueError(f"usage: omega config {args.action} TOOL_ID")
            tool_id = registry.get(args.key).id
            disabled = set(settings.disabled_tools)
            (disabled.add if args.action == "disable" else disabled.discard)(tool_id)
            settings.disabled_tools = sorted(disabled)
        settings.save(path)
    except (ValueError, RegistryError) as exc:
        ui.error(str(exc))
        return 2
    except OSError as exc:
        ui.error(f"could not save settings: {exc.strerror}")
        return 1
    ui.success(f"Saved to {path}")
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    settings = Settings.load()
    setup_logging(settings)
    load_errors = load_builtin_tools()
    ui = UI(settings)
    for message in load_errors:
        ui.warn(f"tool module skipped: {message}")
    if args.version:
        print(f"omega {__version__}")
        return 0
    try:
        if args.command in (None, "menu"):
            if not (sys.stdin.isatty() and sys.stdout.isatty()):
                ui.error("The interactive menu needs a terminal. Use 'omega --help' for "
                         "non-interactive commands.")
                return 2
            return MenuApp(ui, default_registry, settings).run()
        if args.command == "list":
            return _cmd_list(args, default_registry, ui)
        if args.command == "info":
            return _cmd_info(args, default_registry, ui)
        if args.command == "run":
            return _cmd_run(args, default_registry, settings, ui)
        if args.command == "config":
            return _cmd_config(args, settings, default_registry, ui)
    except RegistryError as exc:
        ui.error(str(exc))
        return 2
    except ValueError as exc:
        ui.error(str(exc))
        return 2
    except KeyboardInterrupt:
        ui.print()
        return 130
    return 2


if __name__ == "__main__":
    raise SystemExit(main())

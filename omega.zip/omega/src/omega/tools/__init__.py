"""Built-in tools. Every module under this package is auto-discovered."""

from __future__ import annotations

import importlib
import logging
import pkgutil

log = logging.getLogger("omega.tools")
load_errors: list[str] = []


def load_builtin_tools() -> list[str]:
    """Import every tool module so its @register decorators run.

    A module that fails to import is skipped and reported, never fatal.
    """
    load_errors.clear()
    for info in pkgutil.walk_packages(__path__, prefix=__name__ + "."):
        if info.name.rsplit(".", 1)[-1].startswith("_"):
            continue
        try:
            importlib.import_module(info.name)
        except Exception as exc:  # isolate a broken module from the rest
            log.exception("failed to load %s", info.name)
            load_errors.append(f"{info.name}: {type(exc).__name__}: {exc}")
    return list(load_errors)

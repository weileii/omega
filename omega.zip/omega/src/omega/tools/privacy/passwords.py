"""Privacy tools 91-93. Everything runs locally; secrets are never logged or transmitted."""

from __future__ import annotations

import math
import re
import secrets
import string
import uuid

from omega.core.registry import Param, Tool, ToolResult, register

_COMMON = {
    "password", "123456", "12345678", "123456789", "qwerty", "abc123", "letmein", "admin",
    "welcome", "iloveyou", "monkey", "dragon", "football", "baseball", "master", "login",
    "passw0rd", "p@ssw0rd", "111111", "000000", "trustno1", "sunshine", "princess", "changeme",
}
_PATTERNS = ("qwerty", "asdf", "zxcv", "1234", "abcd", "password", "letmein", "admin")
_LEET = str.maketrans({"0": "o", "4": "a", "3": "e", "1": "l", "@": "a", "$": "s", "5": "s",
                       "!": "i", "7": "t"})
_WORD_SHAPED = re.compile(r"[A-Z]?[a-z]+|[A-Z]+")
SYMBOLS = "!@#$%^&*()-_=+[]{};:,.<>?/~"
AMBIGUOUS = set("Il1O0o|")


def humanize_seconds(seconds: float) -> str:
    if seconds < 1:
        return "instantly"
    for limit, unit in ((60, "seconds"), (3600, "minutes"), (86400, "hours"),
                        (86400 * 365, "days"), (86400 * 365 * 1000, "years")):
        if seconds < limit:
            divisor = {"seconds": 1, "minutes": 60, "hours": 3600, "days": 86400,
                       "years": 86400 * 365}[unit]
            return f"about {seconds / divisor:,.0f} {unit}"
    return "more than a thousand years"


def estimate_entropy(password: str) -> tuple[float, list[str]]:
    """Heuristic entropy estimate in bits, plus the weaknesses that lowered it."""
    findings: list[str] = []
    pool = 0
    pool += 26 if any(c.islower() for c in password) else 0
    pool += 26 if any(c.isupper() for c in password) else 0
    pool += 10 if any(c.isdigit() for c in password) else 0
    pool += 33 if any(c in string.punctuation or c == " " for c in password) else 0
    pool += 100 if any(ord(c) > 127 for c in password) else 0
    if not password or pool == 0:
        return 0.0, ["Empty password"]
    per_char = math.log2(pool)
    bits = len(password) * per_char
    low = password.lower()
    if low in _COMMON:
        return min(bits, 8.0), ["This is one of the most commonly used passwords"]
    # People choose word-shaped runs ("Troubador", "Summer") far more often than random
    # letters, so price them as words (~1.8 bits/char, max 26 bits) even with l33t swaps.
    # This deliberately under-rates truly random letter runs: it errs on the cautious side.
    norm = password.translate(_LEET)
    word_bits, covered, leet_used = 0.0, 0, False
    for run in re.finditer(r"[A-Za-z]{5,}", norm):
        if _WORD_SHAPED.fullmatch(run.group()):
            word_bits += min(len(run.group()) * 1.8, 26.0)
            covered += len(run.group())
            leet_used = leet_used or password[run.start():run.end()] != run.group()
    if covered:
        adjusted = word_bits + (len(password) - covered) * per_char
        if adjusted < bits:
            bits = adjusted
            findings.append("Contains word-like runs" + (
                " with common character substitutions" if leet_used else ""))
    unique_ratio = len(set(password)) / len(password)
    if unique_ratio < 0.6:
        bits *= 0.5 + 0.5 * unique_ratio
        findings.append("Many repeated characters")
    hits = [p for p in _PATTERNS if p in low]
    if hits:
        bits -= 12 * len(hits)
        findings.append("Contains predictable pattern(s): " + ", ".join(hits))
    seq = sum(1 for i in range(len(low) - 2)
              if ord(low[i + 1]) - ord(low[i]) == 1 and ord(low[i + 2]) - ord(low[i + 1]) == 1)
    if seq:
        bits -= 4 * seq
        findings.append("Contains sequential characters")
    if len(password) < 12:
        findings.append("Shorter than 12 characters")
    return max(bits, 0.0), findings


@register
class PasswordStrength(Tool):
    id = "privacy.password_strength"
    number = 91
    name = "Password Strength Estimator"
    description = "Heuristic strength estimate. The password stays on this machine."
    category = "privacy"
    params = (Param("password", "Password to evaluate (hidden)", "secret"),)

    def run(self, password: str) -> ToolResult:
        bits, findings = estimate_entropy(password)
        rating = ("Very weak" if bits < 28 else "Weak" if bits < 36 else "Fair" if bits < 60
                  else "Strong" if bits < 80 else "Very strong")
        seconds = (2 ** min(bits, 200)) / 2 / 1e10
        rows = [("Length", str(len(password))), ("Estimated entropy", f"{bits:.0f} bits"),
                ("Rating", rating),
                ("Crack time @1e10 guess/s", humanize_seconds(seconds))]
        rows += [("Finding", f) for f in findings]
        return ToolResult(True, self.name,
                          "Heuristic estimate, not a guarantee. The password is never shown or stored.",
                          rows)


@register
class PasswordGenerator(Tool):
    id = "privacy.password_generator"
    number = 92
    name = "Secure Password Generator"
    description = "Generate passwords with the OS secure random source."
    category = "privacy"
    params = (
        Param("length", "Length", "int", default=20, min=8, max=256),
        Param("count", "How many", "int", default=1, min=1, max=20),
        Param("symbols", "Include symbols?", "bool", default=True),
        Param("avoid_ambiguous", "Avoid look-alike characters (Il1O0)?", "bool", default=False),
    )

    def run(self, length: int, count: int, symbols: bool, avoid_ambiguous: bool) -> ToolResult:
        classes = [string.ascii_lowercase, string.ascii_uppercase, string.digits]
        if symbols:
            classes.append(SYMBOLS)
        if avoid_ambiguous:
            classes = ["".join(c for c in cls if c not in AMBIGUOUS) for cls in classes]
        alphabet = "".join(classes)
        rng = secrets.SystemRandom()
        out = []
        for _ in range(count):
            chars = [secrets.choice(cls) for cls in classes]
            chars += [secrets.choice(alphabet) for _ in range(length - len(chars))]
            rng.shuffle(chars)
            out.append("".join(chars))
        bits = length * math.log2(len(alphabet))
        return ToolResult(True, self.name, "Generated locally",
                          [("Alphabet size", str(len(alphabet))), ("Entropy (approx.)", f"{bits:.0f} bits")],
                          "\n".join(out))


@register
class TokenGenerator(Tool):
    id = "privacy.token_generator"
    number = 93
    name = "Random Token Generator"
    description = "Generate hex, URL-safe or UUID tokens."
    category = "privacy"
    params = (
        Param("format", "Format (hex/urlsafe/uuid4)", "choice", default="hex",
              choices=("hex", "urlsafe", "uuid4")),
        Param("nbytes", "Bytes of randomness (ignored for uuid4)", "int", default=32, min=8, max=1024),
        Param("count", "How many", "int", default=1, min=1, max=50),
    )

    def run(self, format: str, nbytes: int, count: int) -> ToolResult:  # noqa: A002
        if format == "hex":
            tokens = [secrets.token_hex(nbytes) for _ in range(count)]
        elif format == "urlsafe":
            tokens = [secrets.token_urlsafe(nbytes) for _ in range(count)]
        else:
            tokens = [str(uuid.uuid4()) for _ in range(count)]
        return ToolResult(True, self.name, "Generated locally", [("Format", format)], "\n".join(tokens))

"""Developer tools 72-74: Base64, URL encoding and text diff."""

from __future__ import annotations

import base64
import binascii
import difflib
from urllib.parse import quote, quote_plus, unquote, unquote_plus

from omega.core.registry import Param, Tool, ToolResult, register


@register
class Base64Tool(Tool):
    id = "dev.base64"
    number = 72
    name = "Base64 Encoder/Decoder"
    description = "Encode text to Base64 or decode Base64 (standard or URL-safe)."
    category = "dev"
    params = (
        Param("mode", "Mode (encode/decode)", "choice", default="encode",
              choices=("encode", "decode")),
        Param("source", "Text", "text"),
        Param("urlsafe", "URL-safe alphabet?", "bool", default=False),
    )

    def run(self, mode: str, source: str, urlsafe: bool) -> ToolResult:
        if mode == "encode":
            raw = source.encode("utf-8")
            enc = base64.urlsafe_b64encode(raw) if urlsafe else base64.b64encode(raw)
            return ToolResult(True, self.name, "Encoded", [("Input bytes", str(len(raw)))],
                              enc.decode("ascii"))
        compact = "".join(source.split())
        if urlsafe:
            compact = compact.translate(str.maketrans("-_", "+/"))
        compact += "=" * (-len(compact) % 4)
        try:
            raw = base64.b64decode(compact, validate=True)
        except (binascii.Error, ValueError) as exc:
            return ToolResult(False, self.name, f"Not valid Base64 ({exc})")
        try:
            text = raw.decode("utf-8")
        except UnicodeDecodeError:
            return ToolResult(True, self.name, "Decoded (binary data, shown as hex)",
                              [("Bytes", str(len(raw)))], raw[:64].hex(" "))
        return ToolResult(True, self.name, "Decoded", [("Bytes", str(len(raw)))], text)


@register
class UrlCodec(Tool):
    id = "dev.url_codec"
    number = 73
    name = "URL Encoder/Decoder"
    description = "Percent-encode or decode text (component or form style)."
    category = "dev"
    params = (
        Param("mode", "Mode (encode/decode)", "choice", default="encode",
              choices=("encode", "decode")),
        Param("source", "Text", "text"),
        Param("style", "Style (component/form)", "choice", default="component",
              choices=("component", "form")),
    )

    def run(self, mode: str, source: str, style: str) -> ToolResult:
        if mode == "encode":
            out = quote(source, safe="") if style == "component" else quote_plus(source)
        else:
            out = unquote(source) if style == "component" else unquote_plus(source)
        return ToolResult(True, self.name, mode.capitalize() + "d", [], out)


@register
class TextDiff(Tool):
    id = "dev.text_diff"
    number = 74
    name = "Text Diff Tool"
    description = "Unified diff of two texts or files."
    category = "dev"
    params = (
        Param("left", "First text, or path to a file", "text_or_file"),
        Param("right", "Second text, or path to a file", "text_or_file"),
        Param("context", "Context lines", "int", default=3, min=0, max=20),
    )

    def run(self, left: str, right: str, context: int) -> ToolResult:
        a, b = left.splitlines(), right.splitlines()
        diff = list(difflib.unified_diff(a, b, "left", "right", n=context, lineterm=""))
        added = sum(1 for d in diff if d.startswith("+") and not d.startswith("+++"))
        removed = sum(1 for d in diff if d.startswith("-") and not d.startswith("---"))
        rows = [("Lines (left / right)", f"{len(a)} / {len(b)}"),
                ("Added", str(added)), ("Removed", str(removed))]
        if len(a) + len(b) <= 20000:
            ratio = difflib.SequenceMatcher(None, a, b, autojunk=True).ratio()
            rows.append(("Similarity", f"{ratio:.1%}"))
        if not diff:
            return ToolResult(True, self.name, "The texts are identical", rows)
        return ToolResult(True, self.name, "Differences found", rows, "\n".join(diff))

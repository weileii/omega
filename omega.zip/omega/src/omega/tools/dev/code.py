"""Developer tools 75-78: code statistics, Python syntax checker, project and dependency inspectors.

All of these are read-only and never import or execute the code they inspect.
"""

from __future__ import annotations

import ast
import importlib.metadata
import os
import re
import tomllib
from collections.abc import Iterator
from pathlib import Path
from typing import Any

from omega.core.registry import Param, Tool, ToolResult, register

SKIP_DIRS = {".git", ".hg", ".svn", "node_modules", "__pycache__", ".venv", "venv", ".tox",
             ".mypy_cache", ".ruff_cache", ".pytest_cache", "dist", "build", ".idea", ".vscode"}
MAX_FILES = 20000
MAX_FILE_BYTES = 2 * 1024 * 1024
_SLASH = ("//",)
LANGUAGES: dict[str, tuple[str, tuple[str, ...]]] = {
    ".py": ("Python", ("#",)), ".js": ("JavaScript", _SLASH), ".ts": ("TypeScript", _SLASH),
    ".jsx": ("JavaScript", _SLASH), ".tsx": ("TypeScript", _SLASH), ".java": ("Java", _SLASH),
    ".c": ("C", _SLASH), ".h": ("C/C++ header", _SLASH), ".cpp": ("C++", _SLASH),
    ".cs": ("C#", _SLASH), ".go": ("Go", _SLASH), ".rs": ("Rust", _SLASH),
    ".kt": ("Kotlin", _SLASH), ".swift": ("Swift", _SLASH), ".php": ("PHP", ("//", "#")),
    ".rb": ("Ruby", ("#",)), ".sh": ("Shell", ("#",)), ".sql": ("SQL", ("--",)),
    ".toml": ("TOML", ("#",)), ".yaml": ("YAML", ("#",)), ".yml": ("YAML", ("#",)),
    ".json": ("JSON", ()), ".html": ("HTML", ()), ".css": ("CSS", ()), ".md": ("Markdown", ()),
}


def iter_files(root: Path, suffixes: set[str] | None = None) -> Iterator[Path]:
    """Yield files under root without following symlinks, skipping junk directories."""
    seen = 0
    for base, dirs, files in os.walk(root, followlinks=False):
        dirs[:] = sorted(d for d in dirs if d not in SKIP_DIRS)
        for name in sorted(files):
            path = Path(base) / name
            if path.is_symlink() or (suffixes and path.suffix.lower() not in suffixes):
                continue
            seen += 1
            if seen > MAX_FILES:
                return
            yield path


@register
class CodeStatistics(Tool):
    id = "dev.code_statistics"
    number = 75
    name = "Code Statistics"
    description = "Count files and code/comment/blank lines per language."
    category = "dev"
    permissions = ("filesystem:read",)
    params = (Param("path", "Directory or file", "path", default="."),)

    def run(self, path: Path) -> ToolResult:
        if not path.exists():
            return ToolResult(False, self.name, f"Path not found: {path}")
        files = [path] if path.is_file() else iter_files(path, set(LANGUAGES))
        stats: dict[str, list[int]] = {}
        skipped = 0
        for f in files:
            lang, prefixes = LANGUAGES.get(f.suffix.lower(), ("", ()))
            if not lang:
                continue
            try:
                if f.stat().st_size > MAX_FILE_BYTES:
                    skipped += 1
                    continue
                text = f.read_text(encoding="utf-8", errors="replace")
            except OSError:
                skipped += 1
                continue
            row = stats.setdefault(lang, [0, 0, 0, 0])
            row[0] += 1
            for line in text.splitlines():
                s = line.strip()
                if not s:
                    row[3] += 1
                elif prefixes and s.startswith(prefixes):
                    row[2] += 1
                else:
                    row[1] += 1
        if not stats:
            return ToolResult(False, self.name, "No recognised source files found")
        rows = [(lang, f"{v[0]} files | {v[1]} code | {v[2]} comment | {v[3]} blank")
                for lang, v in sorted(stats.items(), key=lambda kv: -kv[1][1])]
        tot = [sum(v[i] for v in stats.values()) for i in range(4)]
        rows.append(("TOTAL", f"{tot[0]} files | {tot[1]} code | {tot[2]} comment | {tot[3]} blank"))
        if skipped:
            rows.append(("Skipped", f"{skipped} unreadable or >2 MB files"))
        return ToolResult(True, self.name, "Single-line comments only; block comments count as code", rows)


@register
class PythonSyntaxChecker(Tool):
    id = "dev.python_syntax"
    number = 76
    name = "Python Syntax Checker"
    description = "Parse Python source (file, directory or pasted code). Never executes it."
    category = "dev"
    permissions = ("filesystem:read",)
    params = (Param("target", "Python code, or a file/directory path", "text"),)

    @staticmethod
    def _check(source: str, label: str) -> str | None:
        try:
            ast.parse(source)
        except SyntaxError as exc:
            return f"{label}:{exc.lineno}:{exc.offset}: {exc.msg}"
        except (ValueError, RecursionError, MemoryError) as exc:
            return f"{label}: cannot parse ({type(exc).__name__})"
        return None

    def run(self, target: str) -> ToolResult:
        try:
            path = Path(target).expanduser()
            is_dir, is_file = path.is_dir(), path.is_file()
        except (OSError, ValueError):
            is_dir = is_file = False
        if not is_dir and not is_file:
            err = self._check(target, "<input>")
            if err:
                return ToolResult(False, self.name, "Syntax error", [], err)
            return ToolResult(True, self.name, "No syntax errors")
        files = [path] if is_file else list(iter_files(path, {".py"}))
        errors: list[str] = []
        for f in files:
            try:
                if f.stat().st_size > MAX_FILE_BYTES:
                    continue
                err = self._check(f.read_text(encoding="utf-8", errors="replace"), str(f))
            except OSError as exc:
                err = f"{f}: cannot read ({exc.strerror})"
            if err:
                errors.append(err)
        rows = [("Files checked", str(len(files))), ("Files with errors", str(len(errors)))]
        if errors:
            return ToolResult(False, self.name, "Syntax errors found", rows, "\n".join(errors[:50]))
        return ToolResult(True, self.name, "No syntax errors", rows)


def _load_toml(path: Path) -> dict[str, Any] | None:
    try:
        return tomllib.loads(path.read_text(encoding="utf-8"))
    except (OSError, tomllib.TOMLDecodeError):
        return None


@register
class PythonProjectInspector(Tool):
    id = "dev.python_project"
    number = 77
    name = "Python Project Inspector"
    description = "Summarise a Python project's layout, metadata and tooling."
    category = "dev"
    permissions = ("filesystem:read",)
    params = (Param("path", "Project directory", "path", default="."),)

    def run(self, path: Path) -> ToolResult:
        if not path.is_dir():
            return ToolResult(False, self.name, f"Not a directory: {path}")
        rows: list[tuple[str, str]] = []
        pyproject = path / "pyproject.toml"
        data = _load_toml(pyproject) if pyproject.is_file() else None
        if pyproject.is_file() and data is None:
            rows.append(("pyproject.toml", "present but unreadable or invalid"))
        if data:
            proj = data.get("project", {})
            rows += [("Name", str(proj.get("name", "-"))), ("Version", str(proj.get("version", "-"))),
                     ("Requires Python", str(proj.get("requires-python", "-"))),
                     ("Dependencies", str(len(proj.get("dependencies", [])))),
                     ("Scripts", ", ".join(proj.get("scripts", {})) or "-")]
            tools = sorted(data.get("tool", {}))
            rows.append(("[tool.*] sections", ", ".join(tools) or "-"))
        layout = "src/" if (path / "src").is_dir() else "flat"
        packages = [p.parent.name for p in
                    (list((path / "src").glob("*/__init__.py")) + list(path.glob("*/__init__.py")))]
        py_count = sum(1 for _ in iter_files(path, {".py"}))
        checks = {
            "Tests dir": (path / "tests").is_dir() or (path / "test").is_dir(),
            "README": any(path.glob("README*")), "LICENSE file": any(path.glob("LICENSE*")),
            ".gitignore": (path / ".gitignore").is_file(),
            "CI workflows": (path / ".github" / "workflows").is_dir(),
            "setup.py / setup.cfg": (path / "setup.py").is_file() or (path / "setup.cfg").is_file(),
            "requirements*.txt": any(path.glob("requirements*.txt")),
        }
        rows += [("Layout", layout), ("Packages", ", ".join(sorted(set(packages))) or "-"),
                 ("Python files", str(py_count))]
        rows += [(k, "yes" if v else "no") for k, v in checks.items()]
        return ToolResult(True, self.name, str(path.resolve()), rows)


_REQ = re.compile(r"^\s*([A-Za-z0-9][A-Za-z0-9._-]*)\s*(?:\[[^\]]*\])?\s*([^;#]*)")


def parse_requirement(line: str) -> tuple[str, str] | None:
    line = line.strip()
    if not line or line.startswith(("#", "-", ".", "git+", "http://", "https://")):
        return None
    m = _REQ.match(line)
    return (m.group(1), m.group(2).strip()) if m else None


def _installed(name: str) -> str:
    try:
        return importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        return "not installed"


@register
class DependencyInspector(Tool):
    id = "dev.dependency_inspector"
    number = 78
    name = "Dependency Inspector"
    description = "List declared dependencies and whether each is installed here."
    category = "dev"
    permissions = ("filesystem:read",)
    params = (Param("path", "Project directory, pyproject.toml or requirements file", "path",
                    default="."),)

    def run(self, path: Path) -> ToolResult:
        declared: list[tuple[str, str, str]] = []  # (group, name, spec)
        if path.is_dir():
            sources = [path / "pyproject.toml", *sorted(path.glob("requirements*.txt"))]
        else:
            sources = [path]
        found = False
        for src in sources:
            if not src.is_file():
                continue
            found = True
            if src.suffix == ".toml":
                data = _load_toml(src)
                if data is None:
                    return ToolResult(False, self.name, f"Cannot parse {src.name}")
                proj = data.get("project", {})
                groups = {"main": proj.get("dependencies", [])}
                groups.update({f"extra:{k}": v for k, v in proj.get("optional-dependencies", {}).items()})
                groups.update({f"group:{k}": [x for x in v if isinstance(x, str)]
                               for k, v in data.get("dependency-groups", {}).items()})
                for group, items in groups.items():
                    for item in items:
                        parsed = parse_requirement(item)
                        if parsed:
                            declared.append((group, *parsed))
            else:
                try:
                    lines = src.read_text(encoding="utf-8", errors="replace").splitlines()
                except OSError as exc:
                    return ToolResult(False, self.name, f"Cannot read {src}: {exc.strerror}")
                for line in lines:
                    parsed = parse_requirement(line)
                    if parsed:
                        declared.append((src.name, *parsed))
        if not found:
            return ToolResult(False, self.name, "No pyproject.toml or requirements file found")
        if not declared:
            return ToolResult(True, self.name, "No dependencies declared")
        missing = 0
        lines_out = []
        for group, name, spec in declared:
            version = _installed(name)
            missing += version == "not installed"
            lines_out.append(f"{group:<18} {name:<26} {spec or '(any)':<16} {version}")
        header = f"{'GROUP':<18} {'PACKAGE':<26} {'REQUIRED':<16} INSTALLED"
        return ToolResult(True, self.name, "Read-only: nothing was installed or changed",
                          [("Declared", str(len(declared))), ("Not installed here", str(missing))],
                          "\n".join([header, *lines_out]))

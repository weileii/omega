"""Developer tools 67-71: JSON, YAML, TOML and XML validators/formatters."""

from __future__ import annotations

import importlib.util
import json
import re
import tomllib
from typing import Any, ClassVar
from xml.etree import ElementTree  # noqa: S405  (DTDs/entities are rejected before parsing)

from omega.core.registry import Param, Tool, ToolResult, register


def _measure(obj: Any) -> tuple[int, int]:
    """Return (max nesting depth, total value count) without recursion."""
    max_depth = total = 0
    stack: list[tuple[Any, int]] = [(obj, 1)]
    while stack:
        item, depth = stack.pop()
        total += 1
        max_depth = max(max_depth, depth)
        if isinstance(item, dict):
            stack.extend((v, depth + 1) for v in item.values())
        elif isinstance(item, list):
            stack.extend((v, depth + 1) for v in item)
    return max_depth, total


def _snippet(source: str, line: int, col: int) -> str:
    lines = source.splitlines() or [""]
    text = lines[min(max(line, 1), len(lines)) - 1]
    start = max(0, col - 40)
    shown = text[start : start + 80]
    return f"{shown}\n{' ' * max(0, col - 1 - start)}^"


@register
class JsonValidator(Tool):
    id = "dev.json_validator"
    number = 67
    name = "JSON Validator"
    description = "Check JSON is well-formed and summarise its structure."
    category = "dev"
    params = (Param("source", "JSON text, or path to a .json file", "text_or_file"),)

    def run(self, source: str) -> ToolResult:
        try:
            data = json.loads(source)
        except json.JSONDecodeError as exc:
            return ToolResult(
                False, self.name, "Invalid JSON",
                [("Error", exc.msg), ("Line", str(exc.lineno)), ("Column", str(exc.colno))],
                _snippet(source, exc.lineno, exc.colno),
            )
        except RecursionError:
            return ToolResult(False, self.name, "Invalid JSON: nesting is too deep")
        depth, total = _measure(data)
        rows = [
            ("Top-level type", type(data).__name__),
            ("Top-level items", str(len(data)) if isinstance(data, (dict, list)) else "-"),
            ("Nesting depth", str(depth)),
            ("Total values", str(total)),
            ("Size", f"{len(source.encode('utf-8'))} bytes"),
        ]
        return ToolResult(True, self.name, "Valid JSON", rows)


@register
class JsonFormatter(Tool):
    id = "dev.json_formatter"
    number = 68
    name = "JSON Formatter"
    description = "Pretty-print or minify JSON."
    category = "dev"
    params = (
        Param("source", "JSON text, or path to a .json file", "text_or_file"),
        Param("indent", "Indent width", "int", default=2, min=0, max=8),
        Param("sort_keys", "Sort object keys?", "bool", default=False),
        Param("minify", "Minify instead of pretty-print?", "bool", default=False),
    )

    def run(self, source: str, indent: int, sort_keys: bool, minify: bool) -> ToolResult:
        try:
            data = json.loads(source)
        except json.JSONDecodeError as exc:
            return ToolResult(False, self.name, f"Invalid JSON at line {exc.lineno}: {exc.msg}")
        except RecursionError:
            return ToolResult(False, self.name, "Invalid JSON: nesting is too deep")
        if minify:
            out = json.dumps(data, separators=(",", ":"), sort_keys=sort_keys, ensure_ascii=False)
        else:
            out = json.dumps(data, indent=indent or None, sort_keys=sort_keys, ensure_ascii=False)
        return ToolResult(True, self.name, "Formatted", [("Output size", f"{len(out)} chars")], out)


@register
class YamlValidator(Tool):
    id = "dev.yaml_validator"
    number = 69
    name = "YAML Validator"
    description = "Check YAML syntax (safe loader only; needs PyYAML)."
    category = "dev"
    params = (Param("source", "YAML text, or path to a .yaml file", "text_or_file"),)

    def available(self) -> tuple[bool, str]:
        if importlib.util.find_spec("yaml") is None:
            return False, "PyYAML is not installed (pip install pyyaml)"
        return True, ""

    def run(self, source: str) -> ToolResult:
        import yaml  # type: ignore[import-untyped]

        try:
            docs = list(yaml.safe_load_all(source))
        except yaml.YAMLError as exc:
            mark = getattr(exc, "problem_mark", None)
            rows = [("Error", str(getattr(exc, "problem", exc)))]
            if mark is not None:
                rows += [("Line", str(mark.line + 1)), ("Column", str(mark.column + 1))]
            return ToolResult(False, self.name, "Invalid YAML", rows)
        kinds = sorted({type(d).__name__ for d in docs})
        return ToolResult(True, self.name, "Valid YAML", [
            ("Documents", str(len(docs))), ("Top-level types", ", ".join(kinds) or "-")])


@register
class TomlValidator(Tool):
    id = "dev.toml_validator"
    number = 70
    name = "TOML Validator"
    description = "Check TOML syntax and list its top-level keys."
    category = "dev"
    params = (Param("source", "TOML text, or path to a .toml file", "text_or_file"),)

    def run(self, source: str) -> ToolResult:
        try:
            data = tomllib.loads(source)
        except tomllib.TOMLDecodeError as exc:
            return ToolResult(False, self.name, "Invalid TOML", [("Error", str(exc))])
        depth, total = _measure(data)
        return ToolResult(True, self.name, "Valid TOML", [
            ("Top-level keys", ", ".join(list(data)[:20]) or "-"),
            ("Nesting depth", str(depth)), ("Total values", str(total))])


@register
class XmlValidator(Tool):
    id = "dev.xml_validator"
    number = 71
    name = "XML Validator"
    description = "Check XML is well-formed. DTDs and entities are refused for safety."
    category = "dev"
    params = (Param("source", "XML text, or path to an .xml file", "text_or_file"),)
    _DTD: ClassVar[re.Pattern[str]] = re.compile(r"<!\s*(DOCTYPE|ENTITY)", re.IGNORECASE)

    def run(self, source: str) -> ToolResult:
        if self._DTD.search(source):
            return ToolResult(
                False, self.name,
                "Refused: DTD/ENTITY declarations are not parsed (entity-expansion attacks).")
        try:
            root = ElementTree.fromstring(source)  # noqa: S314
        except ElementTree.ParseError as exc:
            line, col = exc.position
            return ToolResult(False, self.name, "Invalid XML",
                              [("Error", str(exc)), ("Line", str(line)), ("Column", str(col + 1))])
        count = attrs = max_depth = 0
        stack = [(root, 1)]
        while stack:
            node, depth = stack.pop()
            count += 1
            attrs += len(node.attrib)
            max_depth = max(max_depth, depth)
            stack.extend((child, depth + 1) for child in node)
        return ToolResult(True, self.name, "Well-formed XML", [
            ("Root element", root.tag), ("Elements", str(count)),
            ("Attributes", str(attrs)), ("Max depth", str(max_depth))])

"""Data & Conversion tool 85: Number Base Converter."""

from __future__ import annotations

from omega.core.registry import Param, Tool, ToolResult, register

_DIGITS = "0123456789abcdefghijklmnopqrstuvwxyz"
MAX_CHARS = 4000  # stays under CPython's int/str conversion limit


def to_base(n: int, base: int) -> str:
    if n == 0:
        return "0"
    sign, n = ("-" if n < 0 else ""), abs(n)
    out = []
    while n:
        n, r = divmod(n, base)
        out.append(_DIGITS[r])
    return sign + "".join(reversed(out))


@register
class NumberBaseConverter(Tool):
    id = "data.number_base"
    number = 85
    name = "Number Base Converter"
    description = "Convert integers between bases 2-36 (0x/0o/0b prefixes accepted)."
    category = "data"
    params = (
        Param("value", "Number (e.g. 255, 0xFF, 0b1010, -42)", "text"),
        Param("base", "Input base 2-36 (0 = detect from prefix, else decimal)", "int",
              default=0, min=0, max=36),
        Param("target", "Extra output base (0 = none)", "int", default=0, min=0, max=36),
    )

    def run(self, value: str, base: int, target: int) -> ToolResult:
        text = value.strip().replace("_", "")
        if len(text) > MAX_CHARS:
            return ToolResult(False, self.name, f"Input is longer than {MAX_CHARS} characters")
        if base == 1:
            return ToolResult(False, self.name, "Base 1 is not supported")
        try:
            n = int(text, 0) if base == 0 and text.lower().lstrip("+-").startswith(
                ("0x", "0o", "0b")) else int(text, base or 10)
        except ValueError:
            return ToolResult(False, self.name, f"'{value}' is not a valid number in that base")
        if target == 1:
            return ToolResult(False, self.name, "Base 1 is not supported")
        rows = [("Decimal", str(n)), ("Binary", bin(n)), ("Octal", oct(n)), ("Hexadecimal", hex(n))]
        if target:
            rows.append((f"Base {target}", to_base(n, target)))
        return ToolResult(True, self.name, "Converted", rows)

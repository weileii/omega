"""The interactive, menu-driven OMEGA application."""

from __future__ import annotations

import platform
import sys
import textwrap
from importlib.util import find_spec
from pathlib import Path

from omega import __version__
from omega.config.settings import (
    LOG_LEVELS,
    THEME_NAMES,
    UNICODE_MODES,
    Settings,
    config_path,
    log_path,
)
from omega.core.categories import CATEGORIES, CATEGORY_BY_KEY, TOTAL_TARGET, Category
from omega.core.errors import ParamError
from omega.core.params import coerce
from omega.core.registry import Registry, Tool, ToolResult
from omega.core.runner import run_tool
from omega.ui.console import UI, sanitize

HELP_LINES = (
    "OMEGA is a menu-driven toolkit. Type a number and press Enter.",
    "",
    "  1-9, 10 ..  choose a category or tool from the current menu",
    "  0           go back one level (at the main menu: exit)",
    "  M           jump to the main menu from anywhere",
    "  H / V / S   help / version / settings",
    "  Q           quit",
    "  Ctrl+C      cancel the current input and go back",
    "",
    "Tool inputs: where a prompt says 'text or path', give a file path (or @path to",
    "force a file) to read from disk, or type the text directly.",
    "Press Enter on a prompt to accept the [default] shown.",
    "Secret prompts (passwords) are hidden and never logged.",
    "",
    "Scripting: run 'omega --help' for the non-interactive commands.",
)


class _Quit(Exception):
    """Leave the application."""


class _Main(Exception):
    """Return to the main menu."""


class MenuApp:
    def __init__(
        self,
        ui: UI,
        registry: Registry,
        settings: Settings,
        config_file: Path | None = None,
    ) -> None:
        self.ui = ui
        self.registry = registry
        self.settings = settings
        self.config_file = config_file or config_path()
        self._notice: tuple[str, str] | None = None

    # ---- plumbing -----------------------------------------------------
    def run(self) -> int:
        self._splash()
        try:
            while True:
                try:
                    self._main_menu()
                    break
                except _Main:
                    continue
        except _Quit:
            pass
        self.ui.print()
        self.ui.print(self.ui.style("muted", "  Goodbye."))
        return 0

    def _screen(self, title: str, crumb: str = "") -> None:
        self.ui.clear()
        self.ui.header(title, crumb)
        self.ui.print()
        if self._notice:
            kind, message = self._notice
            getattr(self.ui, kind)(message)
            self.ui.print()
            self._notice = None

    def _notify(self, kind: str, message: str) -> None:
        self._notice = (kind, message)

    def _pause(self) -> None:
        try:
            self.ui.ask(self.ui.style("muted", "  Press Enter to continue "))
        except (KeyboardInterrupt, EOFError):
            self.ui.print()

    def _choose(self, label: str = "Select") -> str:
        """Read one menu choice. Global keys are handled here; '' means redraw."""
        prompt = self.ui.style("primary", f"\n{label} {self.ui.sym('arrow')} ", bold=True)
        try:
            raw = self.ui.ask(prompt)
        except KeyboardInterrupt:
            self.ui.print()
            return "0"
        except EOFError:
            raise _Quit from None
        key = raw.strip().lower()
        if key == "h":
            self._help()
            return ""
        if key == "v":
            self._version()
            return ""
        if key == "s":
            self._settings_screen()
            return ""
        if key == "q":
            raise _Quit
        if key == "m":
            raise _Main
        return key

    # ---- screens ------------------------------------------------------
    def _splash(self) -> None:
        ui = self.ui
        ui.clear()
        ui.print()
        ui.logo()
        ui.print()
        ui.print(ui.style("text", f"  Modular terminal toolkit  {ui.sym('dot')}  v{__version__}"))
        ready = len(self.registry)
        status = (f"{ready} tools implemented of {TOTAL_TARGET} planned  {ui.sym('dot')}  "
                  f"{platform.system()} {platform.machine()}")
        for line in textwrap.wrap(status, ui.width - 4):
            ui.print(ui.style("muted", "  " + line))
        for warning in self.settings.warnings:
            ui.warn(warning)
        if ui.interactive:
            ui.print()
            self._pause()

    def _main_menu(self) -> None:
        while True:
            self._screen("Main menu")
            entries = []
            for cat in CATEGORIES:
                n = len(self.registry.in_category(cat.key))
                entries.append((str(cat.number), cat.name, f"{n} of {cat.target} tools", n > 0))
            self.ui.menu(entries)
            self.ui.print()
            self.ui.menu([("0", "Exit", "", True)])
            self.ui.print()
            self.ui.controls(back="Exit")
            key = self._choose()
            if key == "0":
                return
            if key == "":
                continue
            cat = next((c for c in CATEGORIES if str(c.number) == key), None)
            if cat is None:
                self._notify("error", f"'{sanitize(key)}' is not a menu option. Enter a number from the list.")
                continue
            self._category_menu(cat)

    def _category_menu(self, cat: Category) -> None:
        while True:
            self._screen(cat.name, "Category")
            tools = self.registry.in_category(cat.key)
            if not tools:
                self.ui.info(f"No tools in this category are implemented yet (target: {cat.target}).")
            entries = []
            for i, tool in enumerate(tools, 1):
                ok, reason = self._usable(tool)
                hint = tool.description if ok else f"unavailable: {reason}"
                entries.append((str(i), tool.name, hint, ok))
            self.ui.menu(entries)
            self.ui.print()
            self.ui.menu([("0", "Back", "", True)])
            self.ui.print()
            self.ui.controls()
            key = self._choose()
            if key == "0":
                return
            if key == "":
                continue
            if not key.isdigit() or not 1 <= int(key) <= len(tools):
                self._notify("error", f"'{sanitize(key)}' is not a valid choice here (1-{len(tools)} or 0).")
                continue
            tool = tools[int(key) - 1]
            ok, reason = self._usable(tool)
            if not ok:
                self._notify("warn", f"{tool.name} is unavailable: {reason}")
                continue
            self._tool_screen(tool, cat)

    def _usable(self, tool: Tool) -> tuple[bool, str]:
        if self.settings.is_disabled(tool.id):
            return False, "disabled in settings"
        return tool.available()

    def _tool_screen(self, tool: Tool, cat: Category) -> None:
        ui = self.ui
        while True:
            self._screen(tool.name, cat.name)
            ui.kv([("Tool", f"#{tool.number:03d}  {tool.id}  v{tool.version}"),
                   ("About", tool.description),
                   ("Permissions", ", ".join(tool.permissions) or "none")])
            ui.print()
            ui.print(ui.style("muted", "  Ctrl+C cancels and goes back."))
            ui.print()
            raw = self._collect(tool)
            if raw is None:
                return
            ui.print()
            with ui.working("Working"):
                result = run_tool(tool, raw, self.settings.disabled_tools)
            self._show_result(result)
            ui.print()
            ui.menu([("R", "Run again", "", True), ("0", "Back", "", True)])
            while True:
                key = self._choose()
                if key == "r":
                    break
                if key == "0":
                    return
                if key:
                    ui.error("Enter R to run again or 0 to go back.")

    def _collect(self, tool: Tool) -> dict[str, str] | None:
        ui = self.ui
        raw: dict[str, str] = {}
        for p in tool.params:
            hint = ""
            if p.choices:
                hint += f" ({'/'.join(p.choices)})"
            if p.kind == "bool":
                hint += " (y/n)"
            if p.default is not None:
                shown = ("yes" if p.default else "no") if isinstance(p.default, bool) else p.default
                hint += f" [{shown}]"
            prompt = ui.style("text", f"  {p.prompt}{hint}: ")
            while True:
                try:
                    value = ui.ask_secret(prompt) if p.kind == "secret" else ui.ask(prompt)
                except (KeyboardInterrupt, EOFError):
                    ui.print()
                    return None
                try:
                    coerce(p, value)
                except ParamError as exc:
                    ui.error(str(exc))
                    continue
                if value != "":
                    raw[p.name] = value
                break
        return raw

    def _show_result(self, result: ToolResult) -> None:
        ui = self.ui
        mark = (ui.style("ok", ui.sym("ok"), bold=True) if result.ok
                else ui.style("error", ui.sym("err"), bold=True))
        ui.print(f"{mark} {ui.style('text', sanitize(result.title), bold=True)}")
        if result.summary:
            ui.print(f"  {ui.style('muted' if result.ok else 'error', sanitize(result.summary))}")
        if result.rows:
            ui.print()
            ui.kv(result.rows)
        if result.text:
            ui.print()
            lines = sanitize(result.text).split("\n")
            limit = self.settings.max_output_lines
            for line in lines[:limit]:
                ui.print("  " + line)
            if len(lines) > limit:
                ui.warn(f"Output truncated: showing {limit} of {len(lines)} lines "
                        "(raise max_output_lines in Settings).")

    def _help(self) -> None:
        self._screen("Help")
        self.ui.panel("Using OMEGA", HELP_LINES)
        self._pause()

    def _version(self) -> None:
        ui = self.ui
        self._screen("Version")

        def has(mod: str) -> str:
            return "installed" if find_spec(mod) else "not installed"

        ui.kv([
            ("OMEGA", __version__),
            ("Tools", f"{len(self.registry)} implemented of {TOTAL_TARGET} planned"),
            ("Python", sys.version.split()[0]),
            ("Platform", platform.platform()),
            ("Config file", str(self.config_file)),
            ("Log file", str(log_path())),
            ("PyYAML (optional)", has("yaml")),
        ])
        self._pause()

    def _settings_screen(self) -> None:
        ui, s = self.ui, self.settings
        while True:
            self._screen("Settings")
            ui.menu([
                ("1", "Theme", s.theme, True),
                ("2", "Colour", "on" if s.color else "off", True),
                ("3", "Clear screen between menus", "on" if s.clear_screen else "off", True),
                ("4", "Unicode drawing characters", s.unicode, True),
                ("5", "Log level", s.log_level, True),
                ("6", "Max output lines", str(s.max_output_lines), True),
                ("7", "Reset to defaults", "", True),
            ])
            ui.print()
            disabled = ", ".join(sorted(s.disabled_tools)) or "none"
            ui.print(ui.style("muted", f"  Disabled tools: {disabled}  (edit via 'omega config')"))
            ui.print(ui.style("muted", f"  Saved to: {self.config_file}"))
            ui.print()
            ui.menu([("0", "Back", "", True)])
            try:
                raw = ui.ask(ui.style("primary", f"\nSetting {ui.sym('arrow')} ", bold=True))
            except (KeyboardInterrupt, EOFError):
                ui.print()
                return
            key = raw.strip().lower()
            if key in ("0", "b", ""):
                return
            if key == "q":
                raise _Quit
            if key == "m":
                raise _Main
            self._edit_setting(key)

    def _edit_setting(self, key: str) -> None:
        s = self.settings
        cycles = {"1": ("theme", THEME_NAMES, s.theme), "4": ("unicode", UNICODE_MODES, s.unicode),
                  "5": ("log_level", LOG_LEVELS, s.log_level)}
        try:
            if key in cycles:
                name, options, current = cycles[key]
                s.set_value(name, options[(options.index(current) + 1) % len(options)])
            elif key in ("2", "3"):
                name = "color" if key == "2" else "clear_screen"
                s.set_value(name, "no" if getattr(s, name) else "yes")
            elif key == "6":
                value = self.ui.ask("  Max output lines (20-5000): ")
                s.set_value("max_output_lines", value)
            elif key == "7":
                if not self.ui.confirm("  Reset all settings to defaults?"):
                    return
                self.settings.__dict__.update(Settings().__dict__)
            else:
                self._notify("error", f"'{sanitize(key)}' is not a setting number.")
                return
        except ValueError as exc:
            self._notify("error", str(exc))
            return
        except (KeyboardInterrupt, EOFError):
            self.ui.print()
            return
        try:
            s.save(self.config_file)
            self._notify("success", "Setting saved.")
        except OSError as exc:
            self._notify("warn", f"Changed for this session, but could not save: {exc.strerror}")


def category_of(tool: Tool) -> Category:
    return CATEGORY_BY_KEY[tool.category]

"""OMEGA colour themes. Roles map to hex colours; empty string means 'no colour'."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Theme:
    name: str
    colors: dict[str, str]


_MONO = {k: "" for k in
         ("bg", "primary", "accent", "highlight", "text", "muted", "ok", "warn", "error")}

THEMES: dict[str, Theme] = {
    "omega": Theme("omega", {
        "bg": "#101827",         # Midnight Navy
        "primary": "#20C5D8",    # Electric Cyan
        "accent": "#6575FF",     # Digital Blue
        "highlight": "#A78BFA",  # Violet
        "text": "#D8E6F5",       # Silver
        "muted": "#7C8BA1",
        "ok": "#4ADE80",
        "warn": "#FBBF24",
        "error": "#F87171",
    }),
    "contrast": Theme("contrast", {
        "bg": "#000000", "primary": "#00F0FF", "accent": "#8FA2FF", "highlight": "#C4A8FF",
        "text": "#FFFFFF", "muted": "#B4BCC8", "ok": "#5CFF8F", "warn": "#FFD84D",
        "error": "#FF7A7A",
    }),
    "mono": Theme("mono", _MONO),
}

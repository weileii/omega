"""OMEGA's terminal renderer: colour, boxes, tables, prompts. Standard library only."""

from __future__ import annotations

import contextlib
import getpass
import os
import re
import shutil
import sys
import textwrap
from collections.abc import Callable, Iterator, Sequence
from typing import TextIO

from omega.config.settings import Settings
from omega.ui.theme import THEMES, Theme

_ANSI = re.compile(r"\x1b\[[0-9;]*m")
_CONTROL = re.compile(r"[\x00-\x08\x0b-\x1f\x7f-\x9f]")

_UNI = {"tl": "╭", "tr": "╮", "bl": "╰", "br": "╯", "h": "─", "v": "│", "dot": "•",
        "ok": "✔", "err": "✖", "warn": "▲", "full": "█", "empty": "░", "omega": "Ω",
        "arrow": "▸", "ell": "…"}
_ASC = {"tl": "+", "tr": "+", "bl": "+", "br": "+", "h": "-", "v": "|", "dot": "*",
        "ok": "+", "err": "x", "warn": "!", "full": "#", "empty": ".", "omega": "O",
        "arrow": ">", "ell": "~"}

LOGO_UNICODE = (
    "  ██████╗ ███╗   ███╗███████╗ ██████╗  █████╗ ",
    " ██╔═══██╗████╗ ████║██╔════╝██╔════╝ ██╔══██╗",
    " ██║   ██║██╔████╔██║█████╗  ██║  ███╗███████║",
    " ██║   ██║██║╚██╔╝██║██╔══╝  ██║   ██║██╔══██║",
    " ╚██████╔╝██║ ╚═╝ ██║███████╗╚██████╔╝██║  ██║",
    "  ╚═════╝ ╚═╝     ╚═╝╚══════╝ ╚═════╝ ╚═╝  ╚═╝",
)
LOGO_ASCII = (
    r"  ___  __  __ _____ ____    _    ",
    r" / _ \|  \/  | ____/ ___|  / \   ",
    r"| | | | |\/| |  _|| |  _  / _ \  ",
    r"| |_| | |  | | |__| |_| |/ ___ \ ",
    r" \___/|_|  |_|_____\____/_/   \_\\",
)


def visible_len(text: str) -> int:
    return len(_ANSI.sub("", text))


def sanitize(text: str) -> str:
    """Strip control characters (incl. ESC) so untrusted data cannot drive the terminal."""
    return _CONTROL.sub("\ufffd", text.replace("\r\n", "\n").replace("\r", "\n"))


def _enable_windows_vt() -> None:
    if os.name != "nt":
        return
    try:
        import ctypes

        kernel32 = ctypes.windll.kernel32  # type: ignore[attr-defined]
        handle = kernel32.GetStdHandle(-11)
        mode = ctypes.c_uint32()
        if kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
            kernel32.SetConsoleMode(handle, mode.value | 0x0004)
    except (AttributeError, OSError):
        pass


def _hex_to_rgb(value: str) -> tuple[int, int, int]:
    value = value.lstrip("#")
    return int(value[0:2], 16), int(value[2:4], 16), int(value[4:6], 16)


def _rgb_to_256(r: int, g: int, b: int) -> int:
    def level(c: int) -> int:
        return 0 if c < 48 else 1 if c < 115 else (c - 35) // 40
    return 16 + 36 * level(r) + 6 * level(g) + level(b)


def _truecolor() -> bool:
    if os.environ.get("COLORTERM", "").lower() in ("truecolor", "24bit"):
        return True
    return os.name == "nt" or "WT_SESSION" in os.environ


class UI:
    def __init__(
        self,
        settings: Settings,
        *,
        out: TextIO | None = None,
        input_fn: Callable[[str], str] | None = None,
        secret_fn: Callable[[str], str] | None = None,
        force_color: bool | None = None,
    ) -> None:
        self.settings = settings
        self.out: TextIO = out if out is not None else sys.stdout
        self._input = input_fn or input
        self._secret = secret_fn or getpass.getpass
        self._force_color = force_color
        self.interactive = bool(getattr(self.out, "isatty", lambda: False)())
        if self.interactive:
            _enable_windows_vt()

    # ---- capabilities -------------------------------------------------
    @property
    def theme(self) -> Theme:
        return THEMES.get(self.settings.theme, THEMES["omega"])

    @property
    def color_enabled(self) -> bool:
        if self._force_color is not None:
            return self._force_color
        return (
            self.settings.color
            and self.interactive
            and "NO_COLOR" not in os.environ
            and os.environ.get("TERM") != "dumb"
        )

    @property
    def unicode_enabled(self) -> bool:
        mode = self.settings.unicode
        if mode != "auto":
            return mode == "on"
        encoding = getattr(self.out, "encoding", None) or "utf-8"
        try:
            "█╗─│Ω▸✔".encode(encoding)
        except (UnicodeEncodeError, LookupError):
            return False
        return True

    @property
    def width(self) -> int:
        """Re-read every call so terminal resizing is honoured."""
        return max(40, min(shutil.get_terminal_size((80, 24)).columns, 110))

    def sym(self, name: str) -> str:
        return (_UNI if self.unicode_enabled else _ASC)[name]

    # ---- styling ------------------------------------------------------
    def _fg(self, hex_color: str) -> str:
        r, g, b = _hex_to_rgb(hex_color)
        return f"38;2;{r};{g};{b}" if _truecolor() else f"38;5;{_rgb_to_256(r, g, b)}"

    def _bg(self, hex_color: str) -> str:
        r, g, b = _hex_to_rgb(hex_color)
        return f"48;2;{r};{g};{b}" if _truecolor() else f"48;5;{_rgb_to_256(r, g, b)}"

    def style(self, role: str, text: str, *, bold: bool = False, bg: str | None = None) -> str:
        if not self.color_enabled:
            return text
        codes: list[str] = []
        if bold:
            codes.append("1")
        fg = self.theme.colors.get(role, "")
        if fg:
            codes.append(self._fg(fg))
        bg_hex = self.theme.colors.get(bg, "") if bg else ""
        if bg_hex:
            codes.append(self._bg(bg_hex))
        return f"\x1b[{';'.join(codes)}m{text}\x1b[0m" if codes else text

    # ---- output -------------------------------------------------------
    def print(self, text: str = "") -> None:
        self.out.write(text + "\n")
        self.out.flush()

    def clear(self) -> None:
        if self.settings.clear_screen and self.interactive:
            self.out.write("\x1b[2J\x1b[H")

    def rule(self, role: str = "muted") -> None:
        self.print(self.style(role, self.sym("h") * self.width))

    def header(self, title: str, crumb: str = "") -> None:
        text = f" {self.sym('omega')} OMEGA  {self.sym('dot')}  {title}"
        if crumb:
            text += f"  {self.sym('dot')}  {crumb}"
        text = text[: self.width].ljust(self.width)
        if self.color_enabled and self.theme.colors.get("bg"):
            self.print(self.style("primary", text, bold=True, bg="bg"))
        else:
            self.print(text)
            self.rule()

    def logo(self) -> None:
        if self.width < 52:
            self.print(self.style("primary", f"  {self.sym('omega')}  O M E G A", bold=True))
            return
        lines = LOGO_UNICODE if self.unicode_enabled else LOGO_ASCII
        roles = ("primary", "primary", "accent", "accent", "highlight", "highlight")
        for i, line in enumerate(lines):
            self.print(self.style(roles[min(i, len(roles) - 1)], line, bold=True))

    def panel(self, title: str, lines: Sequence[str], role: str = "primary") -> None:
        w = self.width
        inner = w - 4
        body: list[str] = []
        for line in lines:
            line = sanitize(line)
            if "\x1b" in line or len(line) <= inner:
                body.append(line)
            else:
                body.extend(textwrap.wrap(line, inner, subsequent_indent="  ") or [""])
        h, v = self.sym("h"), self.sym("v")
        label = f" {title} " if title else ""
        top = self.sym("tl") + h + label + h * max(0, w - 3 - len(label)) + self.sym("tr")
        self.print(self.style(role, top))
        edge = self.style(role, v)
        for line in body:
            pad = " " * max(0, inner - visible_len(line))
            shown = line if "\x1b" in line else self.style("text", line)
            self.print(f"{edge} {shown}{pad} {edge}")
        self.print(self.style(role, self.sym("bl") + h * (w - 2) + self.sym("br")))

    def kv(self, rows: Sequence[tuple[str, str]]) -> None:
        if not rows:
            return
        key_w = min(max(len(sanitize(k)) for k, _ in rows), 30)
        val_w = max(10, self.width - key_w - 5)
        for key, value in rows:
            key = sanitize(key)[:key_w]
            chunks: list[str] = []
            for part in sanitize(str(value)).split("\n"):
                chunks.extend(textwrap.wrap(part, val_w, break_long_words=True) or [""])
            for i, chunk in enumerate(chunks or [""]):
                label = self.style("muted", key.ljust(key_w)) if i == 0 else " " * key_w
                self.print(f"  {label}  {self.style('text', chunk)}")

    def table(self, headers: Sequence[str], rows: Sequence[Sequence[str]]) -> None:
        cols = len(headers)
        widths = [max([len(headers[i])] + [len(sanitize(r[i])) for r in rows]) for i in range(cols)]
        budget = self.width - 2 - 2 * (cols - 1)
        while sum(widths) > budget:
            widest = max(range(cols), key=lambda i: widths[i])
            if widths[widest] <= 6:
                break
            widths[widest] -= 1

        def cell(text: str, w: int) -> str:
            text = sanitize(text)
            return text if len(text) <= w else text[: w - 1] + self.sym("ell")

        self.print("  " + "  ".join(
            self.style("accent", cell(h, widths[i]).ljust(widths[i]), bold=True)
            for i, h in enumerate(headers)))
        self.print(self.style("muted", "  " + "  ".join(self.sym("h") * w for w in widths)))
        for row in rows:
            self.print("  " + "  ".join(
                self.style("text", cell(row[i], widths[i]).ljust(widths[i])) for i in range(cols)))

    def menu(self, entries: Sequence[tuple[str, str, str, bool]]) -> None:
        """entries: (key, label, hint, enabled). Lines never exceed the terminal width."""
        width = self.width
        key_w = max((len(e[0]) for e in entries), default=1) + 2
        label_w = max((len(e[1]) for e in entries), default=0)
        label_w = min(label_w, max(8, width - key_w - 6))
        for key, label, hint, enabled in entries:
            role = "text" if enabled else "muted"
            label = sanitize(label)
            label = label if len(label) <= label_w else label[: label_w - 1] + self.sym("ell")
            hint = sanitize(hint)
            tag = self.style("primary" if enabled else "muted", f"[{key}]", bold=True)
            gap = " " * (key_w - len(key) - 2 + 1)
            indent = 2 + key_w + 1
            room = width - indent - label_w - 2
            if hint and len(hint) <= room:
                self.print(f"  {tag}{gap}{self.style(role, label.ljust(label_w))}  "
                           f"{self.style('muted', hint)}")
                continue
            self.print(f"  {tag}{gap}{self.style(role, label)}")
            if hint:
                short = hint if len(hint) <= width - indent else hint[: width - indent - 1] + self.sym("ell")
                self.print(" " * indent + self.style("muted", short))

    def controls(self, *, back: str = "Back") -> None:
        items = [("H", "Help"), ("V", "Version"), ("S", "Settings"),
                 ("M", "Main menu"), ("0", back), ("Q", "Quit")]
        lines: list[list[tuple[str, str]]] = [[]]
        used = 2
        for key, name in items:
            need = len(key) + len(name) + 4 + (2 if lines[-1] else 0)
            if lines[-1] and used + need > self.width:
                lines.append([])
                used = 2
                need -= 2
            lines[-1].append((key, name))
            used += need
        for row in lines:
            self.print("  " + "  ".join(
                f"{self.style('highlight', f'[{k}]', bold=True)} {self.style('muted', n)}"
                for k, n in row))

    def success(self, message: str) -> None:
        self.print(f"{self.style('ok', self.sym('ok'), bold=True)} {sanitize(message)}")

    def error(self, message: str) -> None:
        self.print(f"{self.style('error', self.sym('err'), bold=True)} {sanitize(message)}")

    def warn(self, message: str) -> None:
        self.print(f"{self.style('warn', self.sym('warn'), bold=True)} {sanitize(message)}")

    def info(self, message: str) -> None:
        self.print(f"{self.style('primary', self.sym('dot'))} {sanitize(message)}")

    def progress_bar(self, fraction: float, width: int = 24) -> str:
        fraction = max(0.0, min(1.0, fraction))
        filled = round(fraction * width)
        bar = self.sym("full") * filled + self.sym("empty") * (width - filled)
        return f"{self.style('primary', bar)} {int(fraction * 100):3d}%"

    @contextlib.contextmanager
    def working(self, label: str) -> Iterator[None]:
        if self.interactive:
            self.out.write(f"  {self.style('muted', label + self.sym('ell'))}\r")
            self.out.flush()
        try:
            yield
        finally:
            if self.interactive:
                self.out.write("\x1b[2K\r")
                self.out.flush()

    # ---- input --------------------------------------------------------
    def ask(self, prompt: str) -> str:
        return self._input(prompt)

    def ask_secret(self, prompt: str) -> str:
        return self._secret(prompt)

    def confirm(self, question: str, default: bool = False) -> bool:
        hint = "Y/n" if default else "y/N"
        try:
            answer = self.ask(f"{question} [{hint}] ").strip().lower()
        except (KeyboardInterrupt, EOFError):
            self.print()
            return False
        if not answer:
            return default
        return answer in ("y", "yes")

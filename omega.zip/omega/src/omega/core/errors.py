"""OMEGA exception types."""


class OmegaError(Exception):
    """Base class for expected OMEGA errors."""


class ParamError(OmegaError):
    """A tool parameter was missing or invalid."""


class RegistryError(OmegaError):
    """A tool could not be registered or found."""

"""Run a tool safely: validate input, never let a tool crash the application."""

from __future__ import annotations

import logging
from collections.abc import Collection, Mapping

from omega.core.errors import ParamError
from omega.core.params import prepare
from omega.core.registry import Tool, ToolResult

log = logging.getLogger("omega.runner")


def run_tool(
    tool: Tool,
    raw: Mapping[str, str],
    disabled: Collection[str] = (),
) -> ToolResult:
    if tool.id in disabled:
        return ToolResult(False, tool.name, "This tool is disabled in settings.")
    usable, reason = tool.available()
    if not usable:
        return ToolResult(False, tool.name, f"Unavailable: {reason}")
    try:
        values = prepare(tool, raw)
    except ParamError as exc:
        return ToolResult(False, tool.name, str(exc))
    # Argument values are never logged: some tools take secrets.
    log.info("running %s", tool.id)
    has_secret = any(p.kind == "secret" for p in tool.params)
    try:
        return tool.run(**values)
    except Exception as exc:  # tool boundary: report, never crash the app
        if has_secret:
            # Exception text and tracebacks may embed the secret: log the type only.
            log.error("tool %s failed (%s)", tool.id, type(exc).__name__)
        else:
            log.exception("tool %s failed", tool.id)
        detail = type(exc).__name__ if has_secret else f"{type(exc).__name__}: {exc}"
        return ToolResult(False, tool.name, f"Unexpected error ({detail}). See the log.")

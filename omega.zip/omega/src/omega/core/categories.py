"""The ten OMEGA categories and their catalog targets."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Category:
    key: str
    number: int
    name: str
    summary: str
    target: int


CATEGORIES: tuple[Category, ...] = (
    Category("network", 1, "Network & Security", "Interfaces, DNS, ports, TLS, headers", 15),
    Category("osint", 2, "OSINT & Public Information", "Public, lawful lookups only", 15),
    Category("web", 3, "Web & Domain Tools", "URLs, status, redirects, sitemaps", 12),
    Category("files", 4, "File & Metadata Tools", "Inspect, hash, compare, organize", 12),
    Category("system", 5, "System & Diagnostics", "Read-only system reports", 12),
    Category("dev", 6, "Developer Tools", "Validators, encoders, code analysis", 12),
    Category("data", 7, "Data & Conversion", "CSV, JSON, units, bases, text", 12),
    Category("privacy", 8, "Privacy & Data Protection", "Local-only password and secret tools", 10),
    Category("automation", 9, "Automation & Utilities", "Rename, backup, archive", 10),
    Category("core", 10, "OMEGA Core & Plugins", "Plugins, config, diagnostics", 10),
)
CATEGORY_BY_KEY: dict[str, Category] = {c.key: c for c in CATEGORIES}
TOTAL_TARGET = sum(c.target for c in CATEGORIES)

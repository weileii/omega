"""Tool metadata, the Tool base class and the registry the menus read from."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, ClassVar, Literal

from omega.core.categories import CATEGORY_BY_KEY
from omega.core.errors import RegistryError

ParamKind = Literal["text", "text_or_file", "path", "int", "bool", "choice", "secret"]
_ID_RE = re.compile(r"^[a-z][a-z0-9_]*\.[a-z][a-z0-9_]*$")


@dataclass(frozen=True)
class Param:
    """One tool input. The menu prompts for it; the CLI passes it with --arg."""

    name: str
    prompt: str
    kind: ParamKind = "text"
    default: Any = None
    required: bool = True
    choices: tuple[str, ...] = ()
    min: int | None = None
    max: int | None = None


@dataclass
class ToolResult:
    ok: bool
    title: str
    summary: str = ""
    rows: list[tuple[str, str]] = field(default_factory=list)
    text: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "ok": self.ok,
            "title": self.title,
            "summary": self.summary,
            "rows": [{"key": k, "value": v} for k, v in self.rows],
            "text": self.text,
        }


class Tool:
    """Base class. Subclasses set the metadata attributes and implement run()."""

    id: ClassVar[str]
    number: ClassVar[int]
    name: ClassVar[str]
    description: ClassVar[str]
    category: ClassVar[str]
    version: ClassVar[str] = "1.0.0"
    status: ClassVar[str] = "stable"
    permissions: ClassVar[tuple[str, ...]] = ()
    params: ClassVar[tuple[Param, ...]] = ()

    def available(self) -> tuple[bool, str]:
        """Return (usable, reason-if-not). Override for optional dependencies."""
        return True, ""

    def run(self, **values: Any) -> ToolResult:
        raise NotImplementedError


class Registry:
    def __init__(self) -> None:
        self._tools: dict[str, Tool] = {}

    def register(self, tool: Tool) -> None:
        if not _ID_RE.match(tool.id):
            raise RegistryError(f"invalid tool id {tool.id!r}")
        if tool.category not in CATEGORY_BY_KEY:
            raise RegistryError(f"{tool.id}: unknown category {tool.category!r}")
        if not tool.id.startswith(tool.category + "."):
            raise RegistryError(f"{tool.id}: id must start with '{tool.category}.'")
        if tool.id in self._tools:
            raise RegistryError(f"duplicate tool id {tool.id!r}")
        if any(t.number == tool.number for t in self._tools.values()):
            raise RegistryError(f"{tool.id}: catalog number {tool.number} already used")
        self._tools[tool.id] = tool

    def all(self) -> list[Tool]:
        return sorted(self._tools.values(), key=lambda t: t.number)

    def in_category(self, key: str) -> list[Tool]:
        return [t for t in self.all() if t.category == key]

    def get(self, ref: str) -> Tool:
        """Find a tool by full id ('dev.json_validator'), short name or number."""
        norm = ref.strip().lower().replace("-", "_")
        if norm in self._tools:
            return self._tools[norm]
        matches = [t for t in self._tools.values() if t.id.split(".", 1)[1] == norm]
        if not matches and norm.isdigit():
            matches = [t for t in self._tools.values() if t.number == int(norm)]
        if len(matches) == 1:
            return matches[0]
        if matches:
            raise RegistryError(f"{ref!r} is ambiguous; use the full id")
        raise RegistryError(f"unknown tool {ref!r}")

    def __len__(self) -> int:
        return len(self._tools)


default_registry = Registry()


def register(cls: type[Tool]) -> type[Tool]:
    """Class decorator: instantiate the tool and add it to the default registry."""
    default_registry.register(cls())
    return cls

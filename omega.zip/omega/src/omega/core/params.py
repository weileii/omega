"""Parameter validation shared by the interactive menu and the CLI."""

from __future__ import annotations

from collections.abc import Mapping
from pathlib import Path
from typing import Any

from omega.core.errors import ParamError
from omega.core.registry import Param, Tool

MAX_INPUT_BYTES = 10 * 1024 * 1024
_TRUE = {"1", "y", "yes", "true", "on"}
_FALSE = {"0", "n", "no", "false", "off"}


def read_text_file(path: Path) -> str:
    try:
        size = path.stat().st_size
    except OSError as exc:
        raise ParamError(f"cannot read {path}: {exc.strerror}") from exc
    if size > MAX_INPUT_BYTES:
        raise ParamError(f"{path} is larger than {MAX_INPUT_BYTES // (1024 * 1024)} MB")
    try:
        return path.read_text(encoding="utf-8-sig", errors="replace")
    except OSError as exc:
        raise ParamError(f"cannot read {path}: {exc.strerror}") from exc


def _is_file(raw: str) -> bool:
    try:
        return Path(raw).expanduser().is_file()
    except (OSError, ValueError):
        return False


def _default_text(default: Any) -> str:
    if isinstance(default, bool):
        return "yes" if default else "no"
    return str(default)


def coerce(param: Param, raw: str | None) -> Any:
    """Convert raw text to the parameter's type, or raise ParamError."""
    if raw is None or raw == "":
        if param.default is not None:
            raw = _default_text(param.default)
        elif param.required:
            raise ParamError(f"'{param.name}' is required")
        else:
            return None
    kind = param.kind
    if kind in ("text", "secret"):
        return raw
    if kind == "text_or_file":
        if raw.startswith("@"):
            target = Path(raw[1:]).expanduser()
            if not target.is_file():
                raise ParamError(f"file not found: {raw[1:]}")
            return read_text_file(target)
        if _is_file(raw):
            return read_text_file(Path(raw).expanduser())
        return raw
    if kind == "path":
        return Path(raw).expanduser()
    if kind == "int":
        try:
            number = int(raw.strip())
        except ValueError:
            raise ParamError(f"'{param.name}' must be a whole number") from None
        if param.min is not None and number < param.min:
            raise ParamError(f"'{param.name}' must be at least {param.min}")
        if param.max is not None and number > param.max:
            raise ParamError(f"'{param.name}' must be at most {param.max}")
        return number
    if kind == "bool":
        low = raw.strip().lower()
        if low in _TRUE:
            return True
        if low in _FALSE:
            return False
        raise ParamError(f"'{param.name}' must be yes or no")
    if kind == "choice":
        low = raw.strip().lower()
        for choice in param.choices:
            if choice.lower() == low:
                return choice
        raise ParamError(f"'{param.name}' must be one of: {', '.join(param.choices)}")
    raise ParamError(f"unsupported parameter kind {kind!r}")


def prepare(tool: Tool, raw: Mapping[str, str]) -> dict[str, Any]:
    known = {p.name for p in tool.params}
    unknown = sorted(set(raw) - known)
    if unknown:
        expected = ", ".join(sorted(known)) or "(none)"
        raise ParamError(f"unknown argument(s): {', '.join(unknown)}. Expected: {expected}")
    return {p.name: coerce(p, raw.get(p.name)) for p in tool.params}

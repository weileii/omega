"""OMEGA - a modular, menu-driven terminal toolkit."""

__version__ = "0.0.0"

"""Allow ``python -m omega``."""

from omega.cli.main import main

raise SystemExit(main())

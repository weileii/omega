# OMEGA

A modular, **menu-driven** terminal toolkit. Launch it, pick a category, pick a tool by number,
use it, go back, and keep going without restarting. A non-interactive CLI exists for scripting.

**Status: v0.0.0 - early.** 16 of 120 planned tools are implemented (see
[docs/tool-catalog.md](docs/tool-catalog.md)). Categories with nothing implemented say so
in the menu; they do not contain placeholder tools.

## Install and run

Requires Python 3.11+. No third-party runtime dependencies (PyYAML is optional, for the YAML validator).

```bash
python -m pip install -e .          # or:  PYTHONPATH=src python -m omega
omega                                # interactive menu
```

## Menu keys

| Key | Action |
|-----|--------|
| number | choose a category / tool |
| `0` | back (at the main menu: exit) |
| `M` | jump to the main menu |
| `H` `V` `S` | help, version, settings |
| `Q` | quit |
| Ctrl+C | cancel current input and go back |

Invalid input shows a message and never exits the program. Where a prompt says "text or path",
give a file path (or `@path` to force a file) or type the text directly. Password prompts are hidden.

## Non-interactive use

```bash
omega list [--category dev] [--json]
omega info json_validator
omega run json_validator -a 'source={"a":1}' [--json]
echo 'my password' | omega run password_strength -a password=-     # secrets via stdin/prompt
omega config show | path | set theme mono | disable dev.base64 | enable dev.base64 | reset
```

Exit codes: `0` success, `1` the tool reported a failure, `2` usage error.
Tools are addressed by id (`dev.json_validator`), short name (`json_validator`) or catalog number (`67`).

## Implemented now

Developer Tools 67-78 (JSON/YAML/TOML/XML validators, JSON formatter, Base64, URL codec, text diff,
code statistics, Python syntax checker, project and dependency inspectors),
Number Base Converter (85), Privacy tools 91-93 (password strength, password generator, token generator).

## Safety properties (each covered by a test)

- Tools run behind a boundary: a crash in a tool becomes an error message, not a crash of OMEGA.
- Secrets are read without echo, never written to logs, never shown in results.
- All text shown in the terminal is stripped of control characters, so a hostile file cannot
  inject escape sequences.
- The XML validator refuses DTD/entity declarations. Python code is parsed, never executed.
- Settings are written atomically; a corrupt config falls back to defaults with a warning.

## Configuration

Stored in `config.json` under `%APPDATA%\omega` (Windows), `~/Library/Application Support/omega`
(macOS) or `~/.config/omega` (Linux). Override with `OMEGA_HOME`. Edit through the in-app Settings
screen (`S`) or `omega config`. Logs go to `logs/omega.log` in the same folder.

## Adding a tool

Create a module under `src/omega/tools/<category>/`, subclass `Tool`, decorate with `@register`.
It is discovered automatically; the menu, CLI and catalog pick it up with no other edits.
Run `python scripts/gen_catalog.py` to refresh the catalog doc.

## Development

```bash
python -m pip install -e ".[dev]"
pytest --cov=omega
ruff check . && mypy src/omega
```
The tests are plain `unittest` and also run with `python -m unittest discover -s tests -t .`.

## Not done yet

Network, OSINT, Web, File, System, Automation and Core/Plugin categories; the plugin system;
Rich/Typer/Pydantic adoption (the current renderer, argparse CLI and dataclass settings use only the
standard library); per-layer coverage gates. See "Verification status" below.

## Verification status (what was actually run)

Run on Linux (Python 3.12) only: unit tests (79 run, 78 pass, 1 skipped), and the real program
driven through a pseudo-terminal with colour, keystrokes, Ctrl+C and 42- and 100-column widths.
**Not run:** Windows, macOS, Python 3.11 (syntax checked against the 3.11 grammar only), Ruff, mypy,
pytest, pytest-cov (none were installable in the build environment). CI config is provided but has
never executed.

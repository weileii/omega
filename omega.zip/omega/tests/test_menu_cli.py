import contextlib
import io
import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from omega.cli.main import main
from tests.helpers import run_menu


class MenuTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.dir = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def test_navigate_run_tool_and_return_without_restart(self):
        # Dev category -> Base64 -> encode -> back -> back -> then password strength via a 2nd category
        out = run_menu(["6", "6", "encode", "hello", "n", "0", "0", "q"], self.dir)
        self.assertIn("aGVsbG8=", out)
        self.assertIn("Developer Tools", out)
        self.assertIn("Goodbye", out)

    def test_invalid_input_never_terminates(self):
        out = run_menu(["abc", "99", "-1", "", "  ", "6", "x", "0", "0", "0"], self.dir)
        self.assertGreaterEqual(out.count("not a menu option"), 3)
        self.assertIn("not a valid choice", out)
        self.assertIn("Goodbye", out)

    def test_global_keys(self):
        out = run_menu(["h", "", "v", "", "6", "m", "q"], self.dir)
        self.assertIn("Using OMEGA", out)
        self.assertIn("Python", out)
        self.assertIn("Goodbye", out)

    def test_main_menu_key_returns_from_category(self):
        out = run_menu(["6", "m", "3", "m", "q"], self.dir)
        # Category 6 -> M -> main menu -> category 3 (Web) -> M -> main menu -> Q
        self.assertEqual(out.count("OMEGA  \u2022  Main menu"), 3)
        self.assertIn("Goodbye", out)

    def test_ctrl_c_goes_back_and_eof_quits(self):
        out = run_menu(["6", "1", "<CTRL-C>", "<CTRL-C>", "<CTRL-C>"], self.dir)
        self.assertIn("Goodbye", out)
        out = run_menu(["6"], self.dir)  # stdin closes
        self.assertIn("Goodbye", out)

    def test_invalid_tool_input_reprompts(self):
        out = run_menu(["6", "2", "{}", "99", "2", "no", "no", "0", "0", "0"], self.dir)
        self.assertIn("at most 8", out)
        self.assertIn("{}", out)

    def test_run_again_loop(self):
        out = run_menu(["6", "1", '{"a":1}', "r", "[1]", "0", "0", "0"], self.dir)
        self.assertEqual(out.count("Valid JSON"), 2)

    def test_secret_prompt_uses_secret_input_and_hides_value(self):
        out = run_menu(["8", "1", "0", "0", "0"], self.dir, secrets=["Sup3r-Secret-Value!"])
        self.assertIn("Estimated entropy", out)
        self.assertNotIn("Sup3r-Secret-Value", out)

    def test_empty_category_is_honest(self):
        out = run_menu(["1", "0", "0"], self.dir)
        self.assertIn("No tools in this category are implemented yet", out)
        self.assertNotIn("coming soon", out.lower())

    def test_settings_change_persists(self):
        out = run_menu(["s", "1", "2", "0", "q"], self.dir)
        saved = json.loads((self.dir / "config.json").read_text())
        self.assertEqual(saved["theme"], "contrast")
        self.assertFalse(saved["color"] is True)
        self.assertIn("Setting saved", out)

    def test_settings_reset_and_validation(self):
        out = run_menu(["s", "6", "3", "6", "100", "7", "y", "x", "0", "q"], self.dir)
        self.assertIn("between 20 and 5000", out)
        self.assertIn("not a setting number", out)
        saved = json.loads((self.dir / "config.json").read_text())
        self.assertEqual(saved["max_output_lines"], 200)

    def test_long_output_is_truncated(self):
        big = "[" + ",".join(str(i) for i in range(500)) + "]"
        out = run_menu(["6", "2", big, "2", "no", "no", "0", "0", "0"], self.dir)
        self.assertIn("Output truncated: showing 200 of", out)
        self.assertNotIn("  499", out)

    def test_terminal_escapes_in_output_are_neutralised(self):
        out = run_menu(["6", "4", "a\x1b[2J\x1b[31m", "b", "3", "0", "0", "0"], self.dir)
        self.assertNotIn("\x1b", out)


class CLITests(unittest.TestCase):
    def run_cli(self, *argv, stdin=""):
        out, err = io.StringIO(), io.StringIO()
        with tempfile.TemporaryDirectory() as home, mock.patch.dict(os.environ, {"OMEGA_HOME": home}), \
                mock.patch("sys.stdin", io.StringIO(stdin)), \
                contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            code = main(list(argv))
        return code, out.getvalue(), err.getvalue()

    def test_version(self):
        code, out, _ = self.run_cli("--version")
        self.assertEqual((code, out.strip()), (0, "omega 0.0.0"))

    def test_list_json_and_category(self):
        code, out, _ = self.run_cli("list", "--json", "--category", "dev")
        data = json.loads(out)
        self.assertEqual(code, 0)
        self.assertEqual(len(data), 12)
        self.assertEqual(self.run_cli("list", "--category", "bogus")[0], 2)

    def test_info(self):
        code, out, _ = self.run_cli("info", "67")
        self.assertEqual(code, 0)
        self.assertIn("JSON Validator", out)

    def test_run_success_and_failure_exit_codes(self):
        code, out, _ = self.run_cli("run", "dev.json_validator", "-a", 'source={"a":1}', "--json")
        self.assertEqual(code, 0)
        self.assertTrue(json.loads(out)["ok"])
        code, out, _ = self.run_cli("run", "json_validator", "-a", "source={", "--json")
        self.assertEqual(code, 1)
        self.assertFalse(json.loads(out)["ok"])

    def test_usage_errors(self):
        self.assertEqual(self.run_cli("run", "nope")[0], 2)
        self.assertEqual(self.run_cli("run", "base64", "-a", "badarg")[0], 2)
        code, out, _ = self.run_cli("run", "base64", "-a", "bogus=1", "--json")
        self.assertEqual(code, 1)
        self.assertIn("unknown argument", json.loads(out)["summary"])

    def test_secret_from_stdin_never_printed(self):
        code, out, _ = self.run_cli("run", "privacy.password_strength", "-a", "password=-",
                                    stdin="Zx9!hunter-two\n")
        self.assertEqual(code, 0)
        self.assertNotIn("hunter-two", out)

    def test_menu_requires_terminal(self):
        code, _, _ = self.run_cli()
        self.assertEqual(code, 2)

    def test_config_commands(self):
        code, out, _ = self.run_cli("config", "show")
        self.assertEqual(code, 0)
        self.assertEqual(json.loads(out)["theme"], "omega")
        self.assertEqual(self.run_cli("config", "set", "theme", "neon")[0], 2)
        self.assertEqual(self.run_cli("config", "set", "theme")[0], 2)
        self.assertEqual(self.run_cli("config", "disable", "no_such_tool")[0], 2)

    def test_disable_enable_roundtrip(self):
        out, err = io.StringIO(), io.StringIO()
        with tempfile.TemporaryDirectory() as home, mock.patch.dict(os.environ, {"OMEGA_HOME": home}), \
                contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            self.assertEqual(main(["config", "disable", "base64"]), 0)
            self.assertEqual(main(["run", "base64", "-a", "source=x", "--json"]), 1)
            self.assertEqual(main(["config", "enable", "base64"]), 0)
            self.assertEqual(main(["run", "base64", "-a", "source=x", "--json"]), 0)


if __name__ == "__main__":
    unittest.main()

import io
import json
import tempfile
import unittest
from pathlib import Path

from omega.config.settings import Settings, omega_home
from omega.ui.console import UI, sanitize, visible_len


class SettingsTests(unittest.TestCase):
    def test_roundtrip_and_validation(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "sub" / "config.json"
            s = Settings()
            s.set_value("theme", "MONO")
            s.set_value("color", "no")
            s.set_value("max_output_lines", "50")
            s.disabled_tools = ["dev.base64", "dev.base64"]
            s.save(path)
            loaded = Settings.load(path)
            self.assertEqual((loaded.theme, loaded.color, loaded.max_output_lines), ("mono", False, 50))
            self.assertEqual(loaded.disabled_tools, ["dev.base64"])  # de-duplicated on save
            self.assertEqual(json.loads(path.read_text())["disabled_tools"], ["dev.base64"])
            self.assertEqual([p.name for p in path.parent.iterdir()], ["config.json"])  # no temp litter

    def test_bad_values_rejected(self):
        s = Settings()
        for key, value in (("theme", "neon"), ("color", "maybe"), ("max_output_lines", "5"),
                           ("max_output_lines", "abc"), ("bogus", "1")):
            with self.assertRaises(ValueError):
                s.set_value(key, value)

    def test_corrupt_file_falls_back_to_defaults(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "config.json"
            path.write_text("{not json", encoding="utf-8")
            s = Settings.load(path)
            self.assertEqual(s.theme, "omega")
            self.assertTrue(s.warnings)
            path.write_text("[1,2]", encoding="utf-8")
            self.assertTrue(Settings.load(path).warnings)

    def test_invalid_fields_ignored_with_warning(self):
        s = Settings.from_dict({"theme": "neon", "color": "off", "disabled_tools": "x"})
        self.assertEqual(s.theme, "omega")
        self.assertEqual(len(s.warnings), 2)

    def test_missing_file_is_defaults(self):
        self.assertEqual(Settings.load(Path("/nonexistent/omega.json")), Settings())

    def test_omega_home_env_override(self):
        import os
        old = os.environ.get("OMEGA_HOME")
        os.environ["OMEGA_HOME"] = "/tmp/xyz-omega"
        try:
            self.assertEqual(omega_home(), Path("/tmp/xyz-omega"))
        finally:
            if old is None:
                del os.environ["OMEGA_HOME"]
            else:
                os.environ["OMEGA_HOME"] = old


class UITests(unittest.TestCase):
    def make(self, **kw):
        out = io.StringIO()
        return UI(Settings(**kw), out=out, force_color=kw.get("force", False)), out

    def test_sanitize_strips_terminal_escapes(self):
        dirty = "ok\x1b[31mred\x1b]0;title\x07\x9b2J\r\nline2"
        clean = sanitize(dirty)
        self.assertNotIn("\x1b", clean)
        self.assertNotIn("\x07", clean)
        self.assertNotIn("\x9b", clean)
        self.assertIn("line2", clean)

    def test_untrusted_text_cannot_inject_ansi(self):
        ui, out = self.make()
        ui.kv([("k\x1b[2J", "v\x1b[31m")])
        ui.panel("t", ["\x1b[2Jboom"])
        ui.error("\x1b[2Jfail")
        self.assertNotIn("\x1b", out.getvalue())

    def test_colour_only_when_enabled(self):
        ui, _ = self.make()
        self.assertEqual(ui.style("primary", "x"), "x")
        out = io.StringIO()
        coloured = UI(Settings(), out=out, force_color=True)
        self.assertIn("\x1b[", coloured.style("primary", "x"))
        mono = UI(Settings(theme="mono"), out=out, force_color=True)
        self.assertEqual(mono.style("primary", "x"), "x")

    def test_ascii_fallback_and_logo(self):
        ui, out = self.make(unicode="off")
        ui.logo()
        ui.panel("T", ["hello"])
        text = out.getvalue()
        self.assertTrue(text.isascii())

    def test_panel_and_table_fit_width(self):
        ui, out = self.make()
        ui.panel("Title", ["word " * 60])
        ui.table(["A", "B"], [["x" * 200, "y"]])
        for line in out.getvalue().splitlines():
            self.assertLessEqual(visible_len(line), ui.width)

    def test_progress_bar_bounds(self):
        ui, _ = self.make()
        self.assertIn("100%", ui.progress_bar(5))
        self.assertIn("  0%", ui.progress_bar(-1))

    def test_confirm_defaults(self):
        out = io.StringIO()
        for answer, default, expect in (("", False, False), ("", True, True), ("y", False, True), ("n", True, False)):
            ui = UI(Settings(), out=out, input_fn=lambda _p, a=answer: a, force_color=False)
            self.assertIs(ui.confirm("ok?", default), expect)


if __name__ == "__main__":
    unittest.main()


class NarrowTerminalTests(unittest.TestCase):
    def test_menu_and_controls_fit_every_width(self):
        import unittest.mock as mock
        entries = [("1", "Network & Security", "Interfaces, DNS, ports, TLS, headers", True),
                   ("10", "OMEGA Core & Plugins", "x" * 90, False)]
        for cols in (40, 42, 60, 80, 120):
            out = io.StringIO()
            ui = UI(Settings(), out=out, force_color=False)
            with mock.patch("shutil.get_terminal_size", return_value=mock.Mock(columns=cols)):
                ui.menu(entries)
                ui.controls()
                limit = ui.width
            for line in out.getvalue().splitlines():
                self.assertLessEqual(len(line), limit, (cols, line))

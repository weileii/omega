import tempfile
import unittest
from pathlib import Path

from omega.core.errors import ParamError, RegistryError
from omega.core.params import coerce, prepare
from omega.core.registry import Param, Registry, Tool, ToolResult
from omega.core.runner import run_tool


def make_tool(**attrs):
    base = {"id": "dev.fake", "number": 900, "name": "Fake", "description": "d", "category": "dev"}
    base.update(attrs)
    return type("FakeTool", (Tool,), base)()


class RegistryTests(unittest.TestCase):
    def test_register_and_lookup(self):
        r = Registry()
        t = make_tool()
        r.register(t)
        self.assertIs(r.get("dev.fake"), t)
        self.assertIs(r.get("FAKE"), t)
        self.assertIs(r.get("900"), t)
        self.assertEqual(r.in_category("dev"), [t])

    def test_rejects_bad_metadata(self):
        r = Registry()
        with self.assertRaises(RegistryError):
            r.register(make_tool(id="BadId"))
        with self.assertRaises(RegistryError):
            r.register(make_tool(category="nope", id="nope.x"))
        with self.assertRaises(RegistryError):
            r.register(make_tool(id="net.fake"))  # prefix must match category

    def test_rejects_duplicates(self):
        r = Registry()
        r.register(make_tool())
        with self.assertRaises(RegistryError):
            r.register(make_tool())
        with self.assertRaises(RegistryError):
            r.register(make_tool(id="dev.other"))  # same number

    def test_unknown_and_ambiguous(self):
        r = Registry()
        r.register(make_tool())
        r.register(make_tool(id="privacy.fake", category="privacy", number=901))
        with self.assertRaises(RegistryError):
            r.get("fake")
        with self.assertRaises(RegistryError):
            r.get("missing")


class ParamTests(unittest.TestCase):
    def test_int_bounds_and_default(self):
        p = Param("n", "n", "int", default=5, min=1, max=10)
        self.assertEqual(coerce(p, ""), 5)
        self.assertEqual(coerce(p, " 7 "), 7)
        for bad in ("0", "11", "x"):
            with self.assertRaises(ParamError):
                coerce(p, bad)

    def test_bool_and_choice(self):
        b = Param("b", "b", "bool", default=False)
        self.assertIs(coerce(b, "YES"), True)
        self.assertIs(coerce(b, ""), False)
        with self.assertRaises(ParamError):
            coerce(b, "maybe")
        c = Param("c", "c", "choice", choices=("Encode", "decode"))
        self.assertEqual(coerce(c, "encode"), "Encode")
        with self.assertRaises(ParamError):
            coerce(c, "nope")

    def test_required_and_optional(self):
        with self.assertRaises(ParamError):
            coerce(Param("x", "x"), "")
        self.assertIsNone(coerce(Param("x", "x", required=False), ""))

    def test_text_or_file(self):
        p = Param("s", "s", "text_or_file")
        with tempfile.TemporaryDirectory() as d:
            f = Path(d) / "a.txt"
            f.write_text("from file", encoding="utf-8")
            self.assertEqual(coerce(p, str(f)), "from file")
            self.assertEqual(coerce(p, "@" + str(f)), "from file")
            with self.assertRaises(ParamError):
                coerce(p, "@" + str(Path(d) / "missing.txt"))
        self.assertEqual(coerce(p, "literal text"), "literal text")
        self.assertEqual(coerce(p, "x" * 5000), "x" * 5000)  # path-too-long must not crash

    def test_unknown_argument_rejected(self):
        with self.assertRaises(ParamError):
            prepare(make_tool(), {"bogus": "1"})


class RunnerTests(unittest.TestCase):
    def test_validation_error_becomes_result(self):
        tool = make_tool(params=(Param("n", "n", "int"),))
        res = run_tool(tool, {})
        self.assertFalse(res.ok)
        self.assertIn("required", res.summary)

    def test_crash_is_contained(self):
        class Boom(Tool):
            id, number, name, description, category = "dev.boom", 901, "Boom", "d", "dev"

            def run(self, **v):
                raise RuntimeError("kaput")

        with self.assertLogs("omega.runner", level="ERROR"):
            res = run_tool(Boom(), {})
        self.assertFalse(res.ok)
        self.assertIn("RuntimeError", res.summary)

    def test_secret_tool_does_not_leak_exception_text(self):
        class Leaky(Tool):
            id, number, name, description, category = "privacy.leaky", 902, "L", "d", "privacy"
            params = (Param("pw", "pw", "secret"),)

            def run(self, pw):
                raise ValueError(f"bad password {pw}")

        with self.assertLogs("omega.runner", level="DEBUG") as logs:
            res = run_tool(Leaky(), {"pw": "hunter2"})
        self.assertNotIn("hunter2", res.summary)
        self.assertNotIn("hunter2", "\n".join(logs.output))

    def test_disabled_and_unavailable(self):
        class Gone(Tool):
            id, number, name, description, category = "dev.gone", 903, "Gone", "d", "dev"

            def available(self):
                return False, "missing dep"

        self.assertIn("missing dep", run_tool(Gone(), {}).summary)
        self.assertIn("disabled", run_tool(make_tool(), {}, disabled={"dev.fake"}).summary)

    def test_success_passthrough(self):
        class Ok(Tool):
            id, number, name, description, category = "dev.ok", 904, "Ok", "d", "dev"

            def run(self, **v):
                return ToolResult(True, "Ok")

        self.assertTrue(run_tool(Ok(), {}).ok)


if __name__ == "__main__":
    unittest.main()

"""Shared test helpers."""

from __future__ import annotations

import io
from collections.abc import Iterable
from pathlib import Path

from omega.config.settings import Settings
from omega.core.registry import Registry
from omega.menu.app import MenuApp
from omega.tools import load_builtin_tools
from omega.core.registry import default_registry
from omega.ui.console import UI


def builtin_registry() -> Registry:
    load_builtin_tools()
    return default_registry


class ScriptedInput:
    """Feeds scripted lines to the UI; raises the given exception when exhausted."""

    def __init__(self, lines: Iterable[str]) -> None:
        self.lines = list(lines)

    def __call__(self, prompt: str = "") -> str:
        if not self.lines:
            raise EOFError
        item = self.lines.pop(0)
        if item == "<CTRL-C>":
            raise KeyboardInterrupt
        return item


def run_menu(lines: list[str], config_dir: Path, secrets: list[str] | None = None) -> str:
    out = io.StringIO()
    settings = Settings()
    secret_in = ScriptedInput(secrets or [])
    ui = UI(settings, out=out, input_fn=ScriptedInput(lines), secret_fn=secret_in, force_color=False)
    app = MenuApp(ui, builtin_registry(), settings, config_file=config_dir / "config.json")
    app.run()
    return out.getvalue()

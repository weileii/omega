import json
import tempfile
import unittest
from pathlib import Path

from omega.core.runner import run_tool
from tests.helpers import builtin_registry


def call(ref, **kw):
    return run_tool(builtin_registry().get(ref), {k: str(v) for k, v in kw.items()})


class CatalogTests(unittest.TestCase):
    def test_every_tool_has_complete_metadata(self):
        for t in builtin_registry().all():
            self.assertTrue(t.name and t.description and t.version, t.id)
            self.assertTrue(1 <= t.number <= 120, t.id)

    def test_no_import_failures(self):
        from omega.tools import load_builtin_tools
        self.assertEqual(load_builtin_tools(), [])


class DevDataTests(unittest.TestCase):
    def test_json_valid_and_invalid(self):
        ok = call("json_validator", source='{"a": [1, {"b": 2}]}')
        self.assertTrue(ok.ok)
        self.assertIn(("Nesting depth", "4"), ok.rows)
        bad = call("json_validator", source='{"a": ')
        self.assertFalse(bad.ok)
        self.assertIn("^", bad.text)

    def test_json_deep_nesting_does_not_crash(self):
        res = call("json_validator", source="[" * 100000 + "]" * 100000)
        self.assertFalse(res.ok)

    def test_json_formatter(self):
        self.assertEqual(call("json_formatter", source='{"b":1,"a":2}', sort_keys="yes", indent=0).text,
                         '{"a": 2, "b": 1}')
        self.assertEqual(call("json_formatter", source='{ "a" : 1 }', minify="yes").text, '{"a":1}')
        self.assertFalse(call("json_formatter", source="{").ok)

    def test_json_from_file(self):
        with tempfile.TemporaryDirectory() as d:
            f = Path(d) / "x.json"
            f.write_text(json.dumps({"k": 1}), encoding="utf-8")
            self.assertTrue(call("json_validator", source=str(f)).ok)

    def test_toml(self):
        self.assertTrue(call("toml_validator", source='a = 1\n[t]\nb = "x"').ok)
        self.assertFalse(call("toml_validator", source="a = ").ok)

    def test_xml(self):
        self.assertTrue(call("xml_validator", source='<a x="1"><b/></a>').ok)
        self.assertFalse(call("xml_validator", source="<a><b></a>").ok)

    def test_xml_rejects_entity_bomb(self):
        bomb = '<?xml version="1.0"?><!DOCTYPE l [<!ENTITY a "aaaa">]><l>&a;</l>'
        res = call("xml_validator", source=bomb)
        self.assertFalse(res.ok)
        self.assertIn("Refused", res.title + res.summary)

    def test_yaml(self):
        tool = builtin_registry().get("yaml_validator")
        if not tool.available()[0]:
            self.skipTest("PyYAML not installed")
        self.assertTrue(call("yaml_validator", source="a: 1\n---\nb: [1, 2]").ok)
        self.assertFalse(call("yaml_validator", source="a: [1, 2").ok)

    def test_yaml_reports_unavailable_without_crash(self):
        tool = builtin_registry().get("yaml_validator")
        if tool.available()[0]:
            self.skipTest("PyYAML is installed")
        self.assertIn("Unavailable", call("yaml_validator", source="a: 1").summary)


class DevEncodingTests(unittest.TestCase):
    def test_base64_roundtrip(self):
        enc = call("base64", mode="encode", source="héllo wörld")
        dec = call("base64", mode="decode", source=enc.text)
        self.assertEqual(dec.text, "héllo wörld")

    def test_base64_urlsafe_and_missing_padding(self):
        enc = call("base64", mode="encode", source="???>>>", urlsafe="yes").text
        self.assertNotIn("+", enc)
        self.assertEqual(call("base64", mode="decode", source=enc.rstrip("="), urlsafe="yes").text, "???>>>")

    def test_base64_invalid_and_binary(self):
        self.assertFalse(call("base64", mode="decode", source="not base64!!").ok)
        self.assertIn("hex", call("base64", mode="decode", source="//79").summary)

    def test_url_codec(self):
        self.assertEqual(call("url_codec", mode="encode", source="a b&c/d").text, "a%20b%26c%2Fd")
        self.assertEqual(call("url_codec", mode="encode", source="a b", style="form").text, "a+b")
        self.assertEqual(call("url_codec", mode="decode", source="a%20b%2Bc").text, "a b+c")

    def test_diff(self):
        same = call("text_diff", left="a\nb", right="a\nb")
        self.assertIn("identical", same.summary)
        diff = call("text_diff", left="a\nb\nc", right="a\nX\nc")
        self.assertIn("-b", diff.text)
        self.assertIn("+X", diff.text)
        self.assertIn(("Added", "1"), diff.rows)


class DevCodeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        (self.root / "src").mkdir()
        (self.root / "src" / "m.py").write_text("# c\nx = 1\n\ny = 2\n", encoding="utf-8")
        (self.root / "src" / "bad.py").write_text("def (:\n", encoding="utf-8")
        (self.root / "node_modules").mkdir()
        (self.root / "node_modules" / "skip.js").write_text("var a;\n", encoding="utf-8")
        (self.root / "pyproject.toml").write_text(
            '[project]\nname = "demo"\nversion = "1.2.3"\nrequires-python = ">=3.11"\n'
            'dependencies = ["definitely-not-installed-xyz>=1.0", "pytest[extra]; python_version>\'3\'"]\n'
            '[project.scripts]\ndemo = "m:main"\n', encoding="utf-8")
        (self.root / "requirements.txt").write_text(
            "# c\n-r other.txt\nrequests==2.0\n-e .\n", encoding="utf-8")

    def tearDown(self):
        self.tmp.cleanup()

    def test_code_stats_counts_and_skips_junk_dirs(self):
        res = call("code_statistics", path=self.root)
        rows = dict(res.rows)
        self.assertEqual(rows["Python"], "2 files | 3 code | 1 comment | 1 blank")
        self.assertNotIn("JavaScript", rows)  # node_modules is skipped

    def test_code_stats_missing_path(self):
        self.assertFalse(call("code_statistics", path=self.root / "nope").ok)

    def test_syntax_checker(self):
        self.assertTrue(call("python_syntax", target="x = 1").ok)
        bad = call("python_syntax", target="def f(:\n  pass")
        self.assertFalse(bad.ok)
        self.assertIn("<input>:1", bad.text)
        res = call("python_syntax", target=self.root)
        self.assertFalse(res.ok)
        self.assertIn("bad.py", res.text)
        self.assertTrue(call("python_syntax", target=self.root / "src" / "m.py").ok)

    def test_syntax_checker_never_executes(self):
        marker = self.root / "pwned"
        code = f"open({str(marker)!r}, 'w').write('x')"
        call("python_syntax", target=code)
        self.assertFalse(marker.exists())

    def test_project_inspector(self):
        rows = dict(call("python_project", path=self.root).rows)
        self.assertEqual(rows["Name"], "demo")
        self.assertEqual(rows["Version"], "1.2.3")
        self.assertEqual(rows["Layout"], "src/")
        self.assertEqual(rows["Scripts"], "demo")
        self.assertFalse(call("python_project", path=self.root / "nope").ok)

    def test_dependency_inspector(self):
        res = call("dependency_inspector", path=self.root)
        self.assertTrue(res.ok)
        self.assertIn("definitely-not-installed-xyz", res.text)
        self.assertIn("not installed", res.text)
        self.assertIn("requests", res.text)
        self.assertNotIn("other.txt", res.text)  # -r lines ignored
        self.assertFalse(call("dependency_inspector", path=self.root / "empty-nope").ok)


class PrivacyTests(unittest.TestCase):
    def test_strength_ordering_and_no_echo(self):
        weak = call("password_strength", password="password")
        mid = call("password_strength", password="Tr0ub4dor&3")
        strong = call("password_strength", password="k9#Qv!2mZp@x7Lw$")
        bits = [float(dict(r.rows)["Estimated entropy"].split()[0]) for r in (weak, mid, strong)]
        self.assertLess(bits[0], bits[1])
        self.assertLess(bits[1], bits[2])
        self.assertLess(bits[1], 40)  # word + l33t must not be rated strong
        for r in (weak, mid, strong):
            blob = json.dumps(r.to_dict())
            self.assertNotIn("Tr0ub4dor", blob)

    def test_strength_empty(self):
        self.assertEqual(dict(call("password_strength", password="x").rows)["Length"], "1")

    def test_generator_properties(self):
        res = call("password_generator", length=24, count=5, symbols="yes")
        pws = res.text.split("\n")
        self.assertEqual(len(pws), 5)
        self.assertEqual(len(set(pws)), 5)
        for pw in pws:
            self.assertEqual(len(pw), 24)
            self.assertTrue(any(c.islower() for c in pw) and any(c.isupper() for c in pw))
            self.assertTrue(any(c.isdigit() for c in pw) and any(not c.isalnum() for c in pw))

    def test_generator_options(self):
        pw = call("password_generator", length=200, symbols="no", avoid_ambiguous="yes").text
        self.assertTrue(pw.isalnum())
        self.assertFalse(set(pw) & set("Il1O0o|"))
        self.assertFalse(call("password_generator", length=4).ok)

    def test_tokens(self):
        self.assertEqual(len(call("token_generator", format="hex", nbytes=16).text), 32)
        self.assertEqual(len(call("token_generator", format="uuid4").text), 36)
        self.assertEqual(len(call("token_generator", format="urlsafe", count=3).text.split("\n")), 3)


class DataTests(unittest.TestCase):
    def test_number_base(self):
        rows = dict(call("number_base", value="0xFF").rows)
        self.assertEqual(rows["Decimal"], "255")
        self.assertEqual(dict(call("number_base", value="ff", base=16).rows)["Decimal"], "255")
        self.assertEqual(dict(call("number_base", value="-10", target=36).rows)["Base 36"], "-a")
        self.assertEqual(dict(call("number_base", value="1_000").rows)["Decimal"], "1000")

    def test_number_base_errors(self):
        self.assertFalse(call("number_base", value="xyz").ok)
        self.assertFalse(call("number_base", value="9" * 5000).ok)
        self.assertFalse(call("number_base", value="1", base=1).ok)
        self.assertFalse(call("number_base", value="12", base=2).ok)


if __name__ == "__main__":
    unittest.main()

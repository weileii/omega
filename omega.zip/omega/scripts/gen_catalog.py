"""Regenerate docs/tool-catalog.md from the live registry (the docs never drift from the code)."""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from omega.core.categories import CATEGORIES, TOTAL_TARGET  # noqa: E402
from omega.core.registry import default_registry  # noqa: E402
from omega.tools import load_builtin_tools  # noqa: E402


def main() -> None:
    load_builtin_tools()
    lines = ["# Tool catalog", "",
             f"Generated from the registry: **{len(default_registry)} of {TOTAL_TARGET}** planned tools "
             "are implemented. Only implemented tools are listed.", ""]
    for cat in CATEGORIES:
        tools = default_registry.in_category(cat.key)
        lines.append(f"## {cat.number:02d} {cat.name} ({len(tools)}/{cat.target})")
        lines.append("")
        if not tools:
            lines += ["_Nothing implemented yet._", ""]
            continue
        lines += ["| # | ID | Name | Description | Permissions |", "|---|----|------|-------------|-------------|"]
        for t in tools:
            lines.append(f"| {t.number:03d} | `{t.id}` | {t.name} | {t.description} | "
                         f"{', '.join(t.permissions) or 'none'} |")
        lines.append("")
    (ROOT / "docs" / "tool-catalog.md").write_text("\n".join(lines), encoding="utf-8")


if __name__ == "__main__":
    main()
